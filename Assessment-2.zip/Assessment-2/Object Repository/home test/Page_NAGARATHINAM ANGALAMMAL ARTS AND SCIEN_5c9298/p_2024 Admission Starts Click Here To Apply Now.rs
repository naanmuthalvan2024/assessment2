<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_2024 Admission Starts Click Here To Apply Now</name>
   <tag></tag>
   <elementGuidId>e1da38a4-26c4-4b50-804a-0b605b1788a6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section/div/marquee/a/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p.fw-bold.text-danger.pt-3.cursor-pointer</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;2024 Admission Starts Click Here To Apply Now!&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>f9f28ce1-0674-438e-8f07-d1bc585206ee</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fw-bold text-danger pt-3 cursor-pointer</value>
      <webElementGuid>a7adb9b3-930a-46ed-af39-479605c4d37a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>2024 Admission Starts Click Here To Apply Now!</value>
      <webElementGuid>03fb1921-7e6c-42da-9924-10593f53c25c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[1]/div[@class=&quot;container&quot;]/marquee[1]/a[1]/p[@class=&quot;fw-bold text-danger pt-3 cursor-pointer&quot;]</value>
      <webElementGuid>c87277d3-f33e-4e26-8612-a8ac13b3ff82</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section/div/marquee/a/p</value>
      <webElementGuid>3d6b347f-eafa-49b1-9c1a-a1f46d2f1772</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Next'])[1]/following::p[1]</value>
      <webElementGuid>d762344d-f789-4504-9a40-efefadabe1c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Previous'])[1]/following::p[1]</value>
      <webElementGuid>365cdc0d-457f-4b3f-87cb-da39a6874e55</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='WELCOME TO NAAS COLLEGE'])[1]/preceding::p[1]</value>
      <webElementGuid>efb94989-e44b-484c-8f69-a80df972625c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ReadMore...'])[1]/preceding::p[1]</value>
      <webElementGuid>68a9e80e-c80e-40fe-b9be-33a904b78ae7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='2024 Admission Starts Click Here To Apply Now!']/parent::*</value>
      <webElementGuid>a8568533-b22a-453b-a7a9-00e4ff3b14ee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a/p</value>
      <webElementGuid>13a3827d-18ed-4ebc-90c5-9c69cbe1f1de</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = '2024 Admission Starts Click Here To Apply Now!' or . = '2024 Admission Starts Click Here To Apply Now!')]</value>
      <webElementGuid>13868a42-3e4f-460b-b69b-2cc23e347d19</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
