<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_NEW REGISTRATION</name>
   <tag></tag>
   <elementGuidId>01f1d861-57fa-4e15-ba64-95b3c52ea846</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section/header/div[2]/div/div[3]/div/a[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.ms-3.btn.btn-primary.btn-sm.rounded-pill.px-3</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;NEW REGISTRATION&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>6246f8fd-5afc-4f1a-b75d-5de28de804cf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value> ms-3 btn btn-primary btn-sm rounded-pill px-3</value>
      <webElementGuid>c1f17087-8cb2-4e3d-becf-d5199fc1602b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/sign-up</value>
      <webElementGuid>ff9c8dac-8994-4abd-9b60-05c35ab87c51</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>NEW REGISTRATION</value>
      <webElementGuid>3f7397b2-89dc-4e5c-85a4-926441e0eb80</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[1]/header[@class=&quot;header bg-white shadow fixed-top&quot;]/div[@class=&quot;container py-2&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;d-none d-sm-block col-md-4&quot;]/div[@class=&quot;text-end pt-2&quot;]/a[@class=&quot;ms-3 btn btn-primary btn-sm rounded-pill px-3&quot;]</value>
      <webElementGuid>e3a2508f-de1e-4497-88d0-3a473a67a14e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section/header/div[2]/div/div[3]/div/a[2]</value>
      <webElementGuid>92cf22ba-2388-43fd-9ae8-0903fe8297df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'NEW REGISTRATION')]</value>
      <webElementGuid>289b1af9-42b8-4576-b4bc-a15137dc1bfb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SIGN IN'])[1]/following::a[1]</value>
      <webElementGuid>35763cd2-e205-4264-96f2-ec40c29a57ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Online admission for the academic year 2024-2025'])[1]/following::a[4]</value>
      <webElementGuid>67f1e33e-5609-424f-8603-438608a3bad1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Apply for UG'])[1]/preceding::a[1]</value>
      <webElementGuid>408e76e1-f50c-445a-a6c8-92ffdfbf4537</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='NEW REGISTRATION']/parent::*</value>
      <webElementGuid>76a3a0c9-5701-4e41-b1f1-a6c6634631a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/sign-up')]</value>
      <webElementGuid>d376fe62-b9d1-4ebb-9899-d0b3519a002b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[2]</value>
      <webElementGuid>7313bedf-1648-45a7-b155-5ef8385b879e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/sign-up' and (text() = 'NEW REGISTRATION' or . = 'NEW REGISTRATION')]</value>
      <webElementGuid>ee6467f8-3443-4c88-a963-60718a1f0924</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
