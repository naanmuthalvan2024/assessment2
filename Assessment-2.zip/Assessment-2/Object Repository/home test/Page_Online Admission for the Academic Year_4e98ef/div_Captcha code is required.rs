<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Captcha code is required</name>
   <tag></tag>
   <elementGuidId>3d5786eb-a994-4a99-b764-d5a876d99e1b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section/div/section/div/div/div[2]/div/div/div/div/div/form/div[4]/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-md-7.col-sm-12.col-12</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div >> internal:has-text=/^Captcha code is required$/ >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>b6844a20-dbc6-4eb4-bd7e-b1837510ca1a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-md-7 col-sm-12 col-12</value>
      <webElementGuid>c13b6b58-ea2c-4f44-a181-f2294cd2e0df</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Captcha code is required</value>
      <webElementGuid>04ffdacd-450c-42b6-a60c-af9a0570ae53</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[1]/div[@class=&quot;inner-wrapper&quot;]/section[@class=&quot;page-content&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-5&quot;]/div[@class=&quot;rounded card-border-btm card&quot;]/div[@class=&quot;card-body&quot;]/div[@class=&quot;pb-1&quot;]/div[@class=&quot;ant-spin-nested-loading&quot;]/div[@class=&quot;ant-spin-container&quot;]/form[1]/div[@class=&quot;mt-3 row&quot;]/div[@class=&quot;col-md-7 col-sm-12 col-12&quot;]</value>
      <webElementGuid>56c95ae7-8f2f-45ee-9259-bb289a395e2e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section/div/section/div/div/div[2]/div/div/div/div/div/form/div[4]/div[2]</value>
      <webElementGuid>8aade449-578b-4012-8329-b8bbf931b559</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Candidate date of birth is required.'])[1]/following::div[3]</value>
      <webElementGuid>9bb5bfce-c837-4457-b845-591f6c966d32</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*'])[2]/following::div[5]</value>
      <webElementGuid>ee3b4f00-2025-4682-bc6b-763c71814fb4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Register'])[1]/preceding::div[2]</value>
      <webElementGuid>7a396cc0-4c00-49b3-9d40-1f86705ae437</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div[2]</value>
      <webElementGuid>bcea974e-490c-434d-ba2d-fab0e9a5e818</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Captcha code is required' or . = 'Captcha code is required')]</value>
      <webElementGuid>6d3ddaa1-5693-4309-a4cf-1cc7615216c9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
