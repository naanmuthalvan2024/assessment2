<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Apply for PG</name>
   <tag></tag>
   <elementGuidId>0941b34c-24df-4b66-8181-6d98a3b895f8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section/div/section/div/div/div/div/div[2]/ul/li[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>li >> internal:has-text=&quot;Apply for PG&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>b6fa333c-bd65-475d-a60f-ad36f0f0e016</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>list-group-item my-2</value>
      <webElementGuid>609dd47e-d753-401f-90d0-3140c172dcc8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Apply for PG</value>
      <webElementGuid>ba4dbf3e-732b-444b-9a69-690954c238ee</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[1]/div[@class=&quot;inner-wrapper&quot;]/section[@class=&quot;page-content&quot;]/div[@class=&quot;container mt-4 mb-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-6 offset-md-3&quot;]/div[@class=&quot;rounded shadow card-border-btm card&quot;]/div[@class=&quot;card-body&quot;]/ul[@class=&quot;list-group list-group-flush fs-6&quot;]/li[@class=&quot;list-group-item my-2&quot;]</value>
      <webElementGuid>f691e705-d98b-4de5-a710-aa5125eea01d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section/div/section/div/div/div/div/div[2]/ul/li[2]</value>
      <webElementGuid>1a0962d1-f33e-471a-919e-231a3bc7fef1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Apply for UG'])[1]/following::li[1]</value>
      <webElementGuid>38474281-1221-4e22-8947-1c66d8772a96</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Prospectus'])[1]/preceding::li[1]</value>
      <webElementGuid>12d13bf2-34f2-43ed-aaf1-76f9de9ff15d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]</value>
      <webElementGuid>f8a509de-a998-44c2-9271-293808deff82</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = 'Apply for PG' or . = 'Apply for PG')]</value>
      <webElementGuid>ebafc806-8739-47a7-bc4d-073442c06bd6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
