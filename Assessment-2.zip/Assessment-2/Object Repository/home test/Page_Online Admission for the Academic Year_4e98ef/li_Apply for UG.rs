<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Apply for UG</name>
   <tag></tag>
   <elementGuidId>ca0af349-0f1a-4a31-9da7-76f2accd16ee</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section/div/section/div/div/div/div/div[2]/ul/li</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.list-group-item.my-2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>li >> internal:has-text=&quot;Apply for UG&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>f17e6842-6f03-4f47-b577-355ccae67acd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>list-group-item my-2</value>
      <webElementGuid>dd6d458f-7df6-4f85-b72f-c1eb18c46385</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Apply for UG</value>
      <webElementGuid>b0fbd7bb-e1bf-437b-b31b-8b9e4dbc3cb8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[1]/div[@class=&quot;inner-wrapper&quot;]/section[@class=&quot;page-content&quot;]/div[@class=&quot;container mt-4 mb-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-6 offset-md-3&quot;]/div[@class=&quot;rounded shadow card-border-btm card&quot;]/div[@class=&quot;card-body&quot;]/ul[@class=&quot;list-group list-group-flush fs-6&quot;]/li[@class=&quot;list-group-item my-2&quot;]</value>
      <webElementGuid>d17994df-679a-4e58-a3c6-dbe9b8d8db2c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section/div/section/div/div/div/div/div[2]/ul/li</value>
      <webElementGuid>699d0446-ccd3-40ce-86c8-d6e7d11ee54e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NEW REGISTRATION'])[1]/following::li[1]</value>
      <webElementGuid>430a6a8f-9845-4fea-bf05-c58fdb1f3c1d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Apply for PG'])[1]/preceding::li[1]</value>
      <webElementGuid>2a858991-816b-4d55-b2df-b8cf873de1a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li</value>
      <webElementGuid>2bbab1bd-630a-47b0-b374-2ae330ed2436</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = 'Apply for UG' or . = 'Apply for UG')]</value>
      <webElementGuid>c7dabd42-ca16-458a-8434-38b81633a538</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
