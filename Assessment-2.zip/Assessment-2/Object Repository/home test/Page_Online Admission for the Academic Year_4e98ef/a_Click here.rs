<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Click here</name>
   <tag></tag>
   <elementGuidId>3c6b6c58-92a4-41d6-aab4-dda3e883e641</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section/div/section/div/div/div[2]/div/div/div/div/div/form/div[6]/div/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.text-center.col-md-12 > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Click here&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>815b88fc-c548-409b-a667-90509bce7bd3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/sign-up</value>
      <webElementGuid>b97e368c-5c68-47b5-bb46-26074b12f9de</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Click here</value>
      <webElementGuid>0bf7f131-1e61-4a82-b9c3-3a20731bc674</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[1]/div[@class=&quot;inner-wrapper&quot;]/section[@class=&quot;page-content&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-5&quot;]/div[@class=&quot;rounded card-border-btm card&quot;]/div[@class=&quot;card-body&quot;]/div[@class=&quot;pb-1&quot;]/div[@class=&quot;ant-spin-nested-loading&quot;]/div[@class=&quot;ant-spin-container&quot;]/form[1]/div[@class=&quot;mt-3 row&quot;]/div[@class=&quot;text-center  col-md-12&quot;]/a[1]</value>
      <webElementGuid>0f994dd5-ec96-436f-8f8e-3c6c60105054</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section/div/section/div/div/div[2]/div/div/div/div/div/form/div[6]/div/a</value>
      <webElementGuid>a9b1fed5-d20d-4507-88c2-c4c13b586305</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Click here')]</value>
      <webElementGuid>4227d4c3-0f2d-40bd-b2a4-02f0ad6bfe35</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign In'])[1]/following::a[1]</value>
      <webElementGuid>82a2ff96-4945-4660-8603-6285ed9aa9cf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Announcements'])[2]/preceding::a[1]</value>
      <webElementGuid>198971e4-bac8-4189-bfe0-9eee6f6ff9a0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Admission 2024 - 2025 : Cost of Application | SF UG - Rs.100,  PG Rs.100 | Bank Charges applicable'])[2]/preceding::a[1]</value>
      <webElementGuid>c13f43af-b038-40b0-9960-8b4b7dd94183</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Click here']/parent::*</value>
      <webElementGuid>f9f9e8d7-5b94-4b37-a9a6-9f4936aa4f76</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/sign-up')])[3]</value>
      <webElementGuid>3b8beeb1-518b-4897-8595-1e73174b3eea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[6]/div/a</value>
      <webElementGuid>4c5020a9-fb80-4415-a249-992b85138e3a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/sign-up' and (text() = 'Click here' or . = 'Click here')]</value>
      <webElementGuid>441412bf-ae17-45ce-a801-64eb98c29c58</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
