<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Education is a prerequisite to progress a_ce263f</name>
   <tag></tag>
   <elementGuidId>0a49bae0-0b67-423f-a288-926151cc3591</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/section[9]/div/div/div/div/div/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-76ecbc3.elementor-widget.elementor-widget-text-editor > div.elementor-widget-container > p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Education is a prerequisite to progress and development of a Society.Nagarathina&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>cc3d950d-eac0-4309-a989-da607b839257</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Education is a prerequisite to progress and development of a Society.Nagarathinam Angalammal Arts &amp; Science (NAAS) College was started in the year 2018 with an aim of imparting quality education at affordable cost especially to the rural and downtrodden student community with a team of highly experienced and committed teachers.</value>
      <webElementGuid>4137ad46-12f8-4fe1-9878-100a42c172e6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/section[@class=&quot;elementor-section elementor-top-section elementor-element elementor-element-139a041 elementor-section-boxed elementor-section-height-default elementor-section-height-default&quot;]/div[@class=&quot;elementor-container elementor-column-gap-default&quot;]/div[@class=&quot;elementor-column elementor-col-66 elementor-top-column elementor-element elementor-element-3724dfa&quot;]/div[@class=&quot;elementor-widget-wrap elementor-element-populated&quot;]/div[@class=&quot;elementor-element elementor-element-76ecbc3 elementor-widget elementor-widget-text-editor&quot;]/div[@class=&quot;elementor-widget-container&quot;]/p[1]</value>
      <webElementGuid>07ed78d3-db24-4f67-b35e-d167c8613f51</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/section[9]/div/div/div/div/div/p</value>
      <webElementGuid>c9aeff6b-4686-4534-b04a-8f0ce4f5a23f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Secretary &amp; Correspondent'])[2]/following::p[1]</value>
      <webElementGuid>af381db4-d982-43eb-83ed-9f019ba09bb9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='M.Com.,B.L.,Ph.D.,'])[1]/following::p[1]</value>
      <webElementGuid>432ad74c-e220-4743-9fb7-e4350da18762</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='“Lead to Illuminate”'])[1]/preceding::p[3]</value>
      <webElementGuid>6b9f26e4-7cd5-4d43-b3d3-0073b07814a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About Us'])[2]/preceding::p[7]</value>
      <webElementGuid>57db38fe-005c-4fbd-b8e4-8db3619c7f45</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Education is a prerequisite to progress and development of a Society.']/parent::*</value>
      <webElementGuid>f8c515ea-67a9-4817-87b0-3ee9bf6d9879</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[9]/div/div/div/div/div/p</value>
      <webElementGuid>04d4a1cf-b6d3-4ce3-bae6-208b41bb4d88</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Education is a prerequisite to progress and development of a Society.Nagarathinam Angalammal Arts &amp; Science (NAAS) College was started in the year 2018 with an aim of imparting quality education at affordable cost especially to the rural and downtrodden student community with a team of highly experienced and committed teachers.' or . = 'Education is a prerequisite to progress and development of a Society.Nagarathinam Angalammal Arts &amp; Science (NAAS) College was started in the year 2018 with an aim of imparting quality education at affordable cost especially to the rural and downtrodden student community with a team of highly experienced and committed teachers.')]</value>
      <webElementGuid>5d5e378f-08f8-444b-a1fa-c006ea053482</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
