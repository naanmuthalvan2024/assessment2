<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Nagarathinam Angalammal Arts  Science C_36a12a</name>
   <tag></tag>
   <elementGuidId>aff90368-acf8-4a62-96fc-abf472123f92</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/section/div/div[2]/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.elementor-column.elementor-col-50.elementor-top-column.elementor-element.elementor-element-40779ba > div.elementor-widget-wrap.elementor-element-populated</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div:nth-child(2) > .elementor-widget-wrap >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>e3951499-3614-45ac-8593-8689eab3631d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-widget-wrap elementor-element-populated</value>
      <webElementGuid>5efaecdc-6473-428f-91e9-b6e87fd42802</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/section[@class=&quot;elementor-section elementor-top-section elementor-element elementor-element-3894b8c elementor-section-boxed elementor-section-height-default elementor-section-height-default&quot;]/div[@class=&quot;elementor-container elementor-column-gap-default&quot;]/div[@class=&quot;elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-40779ba&quot;]/div[@class=&quot;elementor-widget-wrap elementor-element-populated&quot;]</value>
      <webElementGuid>b1ff5302-4ff6-4261-b204-c65b41289353</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/section/div/div[2]/div</value>
      <webElementGuid>42d0ffa9-13ad-43b0-a1b7-7ecae779a605</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nagarathinam Angalammal Arts &amp; Science College'])[1]/following::div[2]</value>
      <webElementGuid>b34e2ffe-7d32-43cf-82de-f077d30d5133</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ABOUT US'])[3]/following::div[4]</value>
      <webElementGuid>532c787a-2d13-4a62-8c52-f8895325c37b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MANAGEMENT'])[1]/preceding::div[3]</value>
      <webElementGuid>99269c7a-e829-4973-8426-113095893828</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dr.S.Nagarathinam'])[1]/preceding::div[10]</value>
      <webElementGuid>5c590fcb-af42-40fe-8394-b4bba7b16c57</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/div[2]/div</value>
      <webElementGuid>b68cfce0-2fa9-44c9-8184-e8212ab33469</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
