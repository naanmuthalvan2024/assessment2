<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_91 96559 15151 naascollegegmail.com</name>
   <tag></tag>
   <elementGuidId>53f3b4d5-8da7-4416-aa5e-f691974a992b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section/div/div/div/div/p[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-md-3 > p:nth-of-type(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;+91 96559 15151 naascollege@gmail.com&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>0f919b0f-61c4-4e1e-9268-2e8cbb243e81</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> +91 96559 15151 naascollege@gmail.com</value>
      <webElementGuid>d4c4e6f0-bd66-4a29-8fbd-2331d8d9e14f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[@class=&quot;theme-bg-dark footer&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;wed-foot-link&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-3&quot;]/p[2]</value>
      <webElementGuid>6034aa72-ecd9-46a5-8616-7dc58c104d56</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section/div/div/div/div/p[2]</value>
      <webElementGuid>221b3efe-52e5-427f-89dc-bd14710dbe86</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='“Lead to Illuminate”'])[1]/following::p[3]</value>
      <webElementGuid>edbef69a-0114-4a95-b06f-e1465a778acb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Secretary &amp; Correspondent'])[2]/following::p[7]</value>
      <webElementGuid>b27ac4ab-9100-4a96-81a7-295895a06160</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About Us'])[2]/preceding::p[1]</value>
      <webElementGuid>774d7c78-4069-4108-9760-d601e9e0b3a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Quick Links'])[1]/preceding::p[2]</value>
      <webElementGuid>c3553fa1-b596-454d-8f09-39974da37d0b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='+91 96559 15151']/parent::*</value>
      <webElementGuid>7e6708d2-228f-46ea-8d36-80806af4859c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/div/div/div/p[2]</value>
      <webElementGuid>bed60c1f-fb59-420a-b7b1-822c62a3e28a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = ' +91 96559 15151 naascollege@gmail.com' or . = ' +91 96559 15151 naascollege@gmail.com')]</value>
      <webElementGuid>72077b9a-8dc1-46bf-b946-be2d1fba5ebf</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
