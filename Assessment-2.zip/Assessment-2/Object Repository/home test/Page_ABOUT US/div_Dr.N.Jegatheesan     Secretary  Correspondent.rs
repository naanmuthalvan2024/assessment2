<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Dr.N.Jegatheesan     Secretary  Correspondent</name>
   <tag></tag>
   <elementGuidId>31fe71fc-b85f-4de6-8da0-1bd5ca906a78</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/section[3]/div/div[2]/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.elementor-column.elementor-col-25.elementor-top-column.elementor-element.elementor-element-83f832e > div.elementor-widget-wrap.elementor-element-populated</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Dr.N.Jegatheesan Secretary &amp; Correspondent&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>d3410adb-7d50-484e-af58-5d93640af033</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-widget-wrap elementor-element-populated</value>
      <webElementGuid>386891fd-5ab8-421b-a331-223e5b619451</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
 
 
 
 
 
 Dr.N.Jegatheesan
 
 
 
 
 Secretary &amp; Correspondent
 
 
 </value>
      <webElementGuid>d01d59d4-0d52-4311-9a2d-95f1d898ab83</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/section[@class=&quot;elementor-section elementor-top-section elementor-element elementor-element-8f88e2c elementor-section-boxed elementor-section-height-default elementor-section-height-default&quot;]/div[@class=&quot;elementor-container elementor-column-gap-default&quot;]/div[@class=&quot;elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-83f832e&quot;]/div[@class=&quot;elementor-widget-wrap elementor-element-populated&quot;]</value>
      <webElementGuid>4bfe1405-33f2-4b2e-aee6-dbd06dfc1bbd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/section[3]/div/div[2]/div</value>
      <webElementGuid>a31b260c-a66b-4117-99e4-0b936806e907</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Chairman'])[1]/following::div[2]</value>
      <webElementGuid>eac679b7-1635-4a45-99c3-f0b2aa1d5f05</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dr.S.Nagarathinam'])[1]/following::div[4]</value>
      <webElementGuid>67e8a905-56fb-47aa-8043-a023241756b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[3]/div/div[2]/div</value>
      <webElementGuid>fde0f47a-ea6c-4df1-8b64-6b311b05771e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
 
 
 
 
 
 Dr.N.Jegatheesan
 
 
 
 
 Secretary &amp; Correspondent
 
 
 ' or . = '
 
 
 
 
 
 Dr.N.Jegatheesan
 
 
 
 
 Secretary &amp; Correspondent
 
 
 ')]</value>
      <webElementGuid>74d29bff-5210-4bd7-a252-4fd97145f10f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
