<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Department Of Manegement Studies</name>
   <tag></tag>
   <elementGuidId>c66d551d-f626-4052-a267-d8f5ba4303c8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[3]/ul/li/ul/li/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.dropdown > ul > li.dropdown > ul > li > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Department Of Manegement Studies&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>79cc8aaa-2e49-4385-96ce-99d3fc33e4cc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/department/22/aviation-management</value>
      <webElementGuid>537515e2-4adf-429f-a8ba-65cdf4d7f6f3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Department Of Manegement Studies</value>
      <webElementGuid>a356d536-c2de-4854-8058-7fbcc9cff636</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[@class=&quot;dropdown&quot;]/ul[1]/li[1]/a[1]</value>
      <webElementGuid>6014b1d3-c4bd-4db8-aab7-d562545cc5b2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[3]/ul/li/ul/li/a</value>
      <webElementGuid>95dbe87e-1ee5-456f-a86d-bb14359a8572</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Department Of Manegement Studies')]</value>
      <webElementGuid>316c068d-6a1a-4a8b-b45d-abcf887a72ba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Departments'])[1]/following::a[1]</value>
      <webElementGuid>bc76db24-6e6b-4e80-ba33-e35141f2600b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Academics'])[1]/following::a[2]</value>
      <webElementGuid>d31909f3-5f3f-4813-a63a-15e6b8d04dd9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Department Of Computer Science'])[1]/preceding::a[1]</value>
      <webElementGuid>c8c46acb-227a-4598-b994-96c20d670bc2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Department Of Forensic Science'])[1]/preceding::a[2]</value>
      <webElementGuid>4e9f4804-2841-46ff-8d85-686930fb4214</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Department Of Manegement Studies']/parent::*</value>
      <webElementGuid>c928f70b-9756-4525-9b1b-937bf1c9d34c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/department/22/aviation-management')]</value>
      <webElementGuid>8acf41da-b15f-4b71-83e6-ff0742e9470f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]/ul/li/ul/li/a</value>
      <webElementGuid>3816e9f7-b879-4f74-9983-4551b0c7813c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/department/22/aviation-management' and (text() = 'Department Of Manegement Studies' or . = 'Department Of Manegement Studies')]</value>
      <webElementGuid>85168651-ddf2-4de1-aaf5-d655a99e1203</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
