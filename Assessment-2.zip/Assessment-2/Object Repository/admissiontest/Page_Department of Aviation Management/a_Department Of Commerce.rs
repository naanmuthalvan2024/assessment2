<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Department Of Commerce</name>
   <tag></tag>
   <elementGuidId>b99d7cc2-6840-4166-a456-5169693dc774</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[3]/ul/li/ul/li[4]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(4) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Department Of Commerce&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>b280e4e4-f7c0-41cb-8b25-20800a88c0d0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/department/1/commerce--management</value>
      <webElementGuid>d28d2d44-5bb5-4efa-9b37-af580b6aaee0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Department Of Commerce</value>
      <webElementGuid>b1f8d336-4bf5-4c23-bb8c-5210073e95a7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[@class=&quot;dropdown&quot;]/ul[1]/li[4]/a[1]</value>
      <webElementGuid>cded995d-4391-498a-ab02-becc595e1553</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[3]/ul/li/ul/li[4]/a</value>
      <webElementGuid>fb831215-06ea-4acd-a55c-5a3dee533ddc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Department Of Commerce')]</value>
      <webElementGuid>25f48945-2add-4916-9a8d-5eaad1aad0d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Department Of Forensic Science'])[1]/following::a[1]</value>
      <webElementGuid>2b98aaf7-351f-47bd-bd5a-77b0801d8740</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Department Of Computer Science'])[1]/following::a[2]</value>
      <webElementGuid>d79fe2f9-af8c-4d57-bd8f-38b9fb5645a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Department Of Hotel Management &amp; Catering Service'])[1]/preceding::a[1]</value>
      <webElementGuid>ac0a8bb0-416d-4f0b-bb2d-83ac6d61893f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Department Of Visual Communication'])[1]/preceding::a[2]</value>
      <webElementGuid>b3314ef9-f839-4072-9be1-940964dbcb94</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Department Of Commerce']/parent::*</value>
      <webElementGuid>f175ad20-cd23-492c-805f-b9886124c7ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/department/1/commerce--management')]</value>
      <webElementGuid>36c36560-54fa-4509-9d6c-3a2764251faa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li/ul/li[4]/a</value>
      <webElementGuid>f500fe80-fc09-44c0-b0e6-9ededeb3ca5d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/department/1/commerce--management' and (text() = 'Department Of Commerce' or . = 'Department Of Commerce')]</value>
      <webElementGuid>55bc2108-9b48-45ba-9a08-453f1bc9cf99</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
