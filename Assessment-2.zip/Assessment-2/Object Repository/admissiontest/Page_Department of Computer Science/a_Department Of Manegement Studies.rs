<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Department Of Manegement Studies</name>
   <tag></tag>
   <elementGuidId>74a2e4d1-05db-48aa-b500-8c51ab07cb0e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[3]/ul/li/ul/li/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.dropdown > ul > li.dropdown > ul > li > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Department Of Manegement Studies&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>468888a6-5c45-4554-8272-c0a4cfc108b5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/department/22/aviation-management</value>
      <webElementGuid>4e4ac6b8-8bc5-4f45-9c4d-e1349e5c39ec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Department Of Manegement Studies</value>
      <webElementGuid>854a188f-fac0-4b2d-a648-3e2e24fddee8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[@class=&quot;dropdown&quot;]/ul[1]/li[1]/a[1]</value>
      <webElementGuid>b130e79a-b0f8-4489-bc96-49375d8d69ac</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[3]/ul/li/ul/li/a</value>
      <webElementGuid>53008a26-d665-4ce3-a2c2-989da19ba044</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Department Of Manegement Studies')]</value>
      <webElementGuid>2954decd-3d6f-4af9-9f28-e1bcfb601d25</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Departments'])[1]/following::a[1]</value>
      <webElementGuid>cd153415-904d-4dcc-9648-4fab4b509b67</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Academics'])[1]/following::a[2]</value>
      <webElementGuid>f77a480b-ce64-49e8-aa64-16d3e4902829</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Department Of Computer Science'])[1]/preceding::a[1]</value>
      <webElementGuid>55b25347-1ade-458a-99e6-5c9ac5377970</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Department Of Forensic Science'])[1]/preceding::a[2]</value>
      <webElementGuid>d40a0452-f825-464e-ae19-d2d5b3a48739</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Department Of Manegement Studies']/parent::*</value>
      <webElementGuid>42b4d63a-c32b-4c8a-8212-7b9934b5c2f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/department/22/aviation-management')]</value>
      <webElementGuid>62a097c6-3f04-4ea1-8034-af04e8a381ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]/ul/li/ul/li/a</value>
      <webElementGuid>301e0075-9a3b-4688-aed3-5bc6be437182</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/department/22/aviation-management' and (text() = 'Department Of Manegement Studies' or . = 'Department Of Manegement Studies')]</value>
      <webElementGuid>29ccb29f-de11-4158-94d2-0efeaf685a58</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
