<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_B.Com_fa-solid fa-chevron-down</name>
   <tag></tag>
   <elementGuidId>6ff38366-bea0-4975-be70-9564b8b45b05</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[3]/ul/li[2]/ul/li/a/i</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.dropdown > ul > li.dropdown > ul > li.dropdown > a > i.fa-solid.fa-chevron-down</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;B.Com &quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
      <webElementGuid>6b031c5a-6f75-4b85-a4d2-58d6465c552f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fa-solid fa-chevron-down</value>
      <webElementGuid>b6321cc0-0fcd-4c94-8574-3c4bdd7678a6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[@class=&quot;dropdown&quot;]/ul[1]/li[@class=&quot;dropdown&quot;]/a[1]/i[@class=&quot;fa-solid fa-chevron-down&quot;]</value>
      <webElementGuid>b5380733-ab83-4c6b-887f-8e68460c91ce</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[3]/ul/li[2]/ul/li/a/i</value>
      <webElementGuid>bff3e50d-08e7-4757-973d-1ae3c30ee4fe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/ul/li/a/i</value>
      <webElementGuid>a587ce41-cd57-4801-b112-fa77125b2546</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
