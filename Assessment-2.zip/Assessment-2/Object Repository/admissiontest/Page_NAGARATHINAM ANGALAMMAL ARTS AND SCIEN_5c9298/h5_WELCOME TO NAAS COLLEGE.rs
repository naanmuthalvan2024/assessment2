<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h5_WELCOME TO NAAS COLLEGE</name>
   <tag></tag>
   <elementGuidId>b9d47343-621a-4cbe-b537-f766bd1c1be7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div[2]/h5</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h5.text-center.text-theme</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;WELCOME TO NAAS COLLEGE&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h5</value>
      <webElementGuid>db572c15-56f0-4b3d-889a-8e530433584f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-center text-theme</value>
      <webElementGuid>652fd7c7-b4db-4737-84b0-5939670104b1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>WELCOME TO NAAS COLLEGE</value>
      <webElementGuid>49a7f39d-c22e-4e4b-9073-159e8a8ae1e8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[@class=&quot;py-4 about_bg mb-4&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-8&quot;]/h5[@class=&quot;text-center text-theme&quot;]</value>
      <webElementGuid>ac9d268b-27d6-42c5-a2aa-c6650a523298</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div[2]/h5</value>
      <webElementGuid>9d654d17-3584-4486-9477-eefe888c5866</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='HELP DESK : +91 96559 15151'])[1]/following::h5[1]</value>
      <webElementGuid>cb82b0c3-5765-4c05-845c-708ec4f4e5cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ReadMore...'])[1]/preceding::h5[1]</value>
      <webElementGuid>49068c79-5792-4f51-823e-d95b380f265a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Vision'])[1]/preceding::h5[1]</value>
      <webElementGuid>4ddaa345-9263-47a7-9b06-ffa77315f989</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='WELCOME TO NAAS COLLEGE']/parent::*</value>
      <webElementGuid>6f271759-435f-47af-9a40-54dde2224753</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h5</value>
      <webElementGuid>62ac5f96-d18f-4f35-90ca-ea84e162ce1c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h5[(text() = 'WELCOME TO NAAS COLLEGE' or . = 'WELCOME TO NAAS COLLEGE')]</value>
      <webElementGuid>4c869170-a49d-41b2-9aa2-85477e6278c4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
