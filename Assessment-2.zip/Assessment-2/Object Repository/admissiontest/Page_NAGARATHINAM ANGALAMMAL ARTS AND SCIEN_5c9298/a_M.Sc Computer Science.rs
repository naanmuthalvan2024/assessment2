<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_M.Sc Computer Science</name>
   <tag></tag>
   <elementGuidId>ab330e59-6797-43e6-9bb5-51087bb5aa33</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[3]/ul/li[3]/ul/li[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;M.Sc Computer Science&quot;s]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>867684d7-971c-45c5-95fc-c54b0cc73f5f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/department/11/computer-science</value>
      <webElementGuid>e0936d7c-56ee-4404-bb74-583c4349d72f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>M.Sc Computer Science</value>
      <webElementGuid>b92ed980-7a71-4203-8388-2031794fe5d5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[@class=&quot;dropdown&quot;]/ul[1]/li[2]/a[1]</value>
      <webElementGuid>79603d47-f7b4-41db-a34f-e4b1b169684f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[3]/ul/li[3]/ul/li[2]/a</value>
      <webElementGuid>686d38b7-1f94-427b-a627-dbc5d9313f57</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'M.Sc Computer Science')]</value>
      <webElementGuid>30b81cc4-7436-4d1a-abd4-ea3b8b4f8ed8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='M.Com General'])[1]/following::a[1]</value>
      <webElementGuid>7507c725-5508-4ffe-b8b2-3e78b3d8636a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PG'])[1]/following::a[2]</value>
      <webElementGuid>82b633b5-081e-41f6-85c4-1c1df5213e60</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Admission'])[1]/preceding::a[1]</value>
      <webElementGuid>ca286500-349b-4fa4-bf44-0ada2f9afcbf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ONLINE APPLICATION'])[1]/preceding::a[2]</value>
      <webElementGuid>040ed53b-e03d-41bc-b8ea-f8ad1eb7daa0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='M.Sc Computer Science']/parent::*</value>
      <webElementGuid>98f09a8c-9259-4a68-92ab-eb4cd208275e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/department/11/computer-science')])[7]</value>
      <webElementGuid>8eae0618-76e8-4fae-8277-728abbbe1dc7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]/ul/li[3]/ul/li[2]/a</value>
      <webElementGuid>d20baace-90f1-4793-beff-08579852f792</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/department/11/computer-science' and (text() = 'M.Sc Computer Science' or . = 'M.Sc Computer Science')]</value>
      <webElementGuid>09755f65-081c-4041-a4b4-c8c86c02ad62</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
