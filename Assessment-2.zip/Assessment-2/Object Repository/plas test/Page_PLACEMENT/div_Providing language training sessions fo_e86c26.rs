<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Providing language training sessions fo_e86c26</name>
   <tag></tag>
   <elementGuidId>4da9cee7-bded-42d0-8582-fc0bcd0d782e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/section[7]/div/div/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-5020bf5.elementor-widget.elementor-widget-text-editor</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>section:nth-child(7) > .elementor-container > .elementor-column > .elementor-widget-wrap > div:nth-child(2)</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>89708d00-5b79-4c5d-841a-0a00e9b4bbd1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-element elementor-element-5020bf5 elementor-widget elementor-widget-text-editor</value>
      <webElementGuid>8a73b86b-3960-45d6-9d59-2704c95c4174</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-id</name>
      <type>Main</type>
      <value>5020bf5</value>
      <webElementGuid>c0535bbc-b3f0-40b2-8b67-2905c7bcb456</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-element_type</name>
      <type>Main</type>
      <value>widget</value>
      <webElementGuid>c3a2cb9a-6700-44ac-83bf-2f7298fcf792</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-widget_type</name>
      <type>Main</type>
      <value>text-editor.default</value>
      <webElementGuid>f40ba2ce-b7ed-4a21-afb5-f35918b7e402</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
 
 
 Providing language training sessions for emulating the communication skills, group discussion techniques, and Interview techniques which are the screening methods used by the organizations these days.
 Developing a sound bond between industry and students by keeping up to the expectations of both.
 Conducting Model Aptitude tests, Mock Group discussions &amp; Mock Interviews to pinnacle in the Recruitment process.
 Continuously updating the database for meeting the different requirements from the organisations and to make students choose the best possible company for their career.
 Updating various departments about the requirements of the industry so as to enable them to get the students ready for the external world.
 In-plant training, Industrial visits, Projects, Guest lectures and other Industry-Institute interaction activities.
 Arranging meeting with eminent personalities from the industry so as to emphasis the ever changing need of the industry and how to make one ready for it.
 Arranging Entrepreneurship Guidance Programmes.
 Career guidance sessions for higher studies.
 Arranging – Industry Institute partnership.
 
 
 </value>
      <webElementGuid>707fdb78-9543-4de9-bc89-e3e8cb249160</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/section[@class=&quot;elementor-section elementor-top-section elementor-element elementor-element-accaccb elementor-section-boxed elementor-section-height-default elementor-section-height-default&quot;]/div[@class=&quot;elementor-container elementor-column-gap-default&quot;]/div[@class=&quot;elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5240834&quot;]/div[@class=&quot;elementor-widget-wrap elementor-element-populated&quot;]/div[@class=&quot;elementor-element elementor-element-5020bf5 elementor-widget elementor-widget-text-editor&quot;]</value>
      <webElementGuid>cc020fd3-2c77-4c61-a2be-be413f1f89bc</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/section[7]/div/div/div/div[2]</value>
      <webElementGuid>b2b6cb9f-f38e-4e5b-8ab3-d2096039c890</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Activity'])[1]/following::div[1]</value>
      <webElementGuid>8605ab86-cf3a-4ee0-90e6-2fc682dd862e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Entrepreneurship Development and Innovation Institute'])[1]/following::div[6]</value>
      <webElementGuid>74f6b110-0f75-4ca0-a12a-18a0cf0c2ec4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[7]/div/div/div/div[2]</value>
      <webElementGuid>63c433da-f546-4df7-b0ab-809e427b83c7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
 
 
 Providing language training sessions for emulating the communication skills, group discussion techniques, and Interview techniques which are the screening methods used by the organizations these days.
 Developing a sound bond between industry and students by keeping up to the expectations of both.
 Conducting Model Aptitude tests, Mock Group discussions &amp; Mock Interviews to pinnacle in the Recruitment process.
 Continuously updating the database for meeting the different requirements from the organisations and to make students choose the best possible company for their career.
 Updating various departments about the requirements of the industry so as to enable them to get the students ready for the external world.
 In-plant training, Industrial visits, Projects, Guest lectures and other Industry-Institute interaction activities.
 Arranging meeting with eminent personalities from the industry so as to emphasis the ever changing need of the industry and how to make one ready for it.
 Arranging Entrepreneurship Guidance Programmes.
 Career guidance sessions for higher studies.
 Arranging – Industry Institute partnership.
 
 
 ' or . = '
 
 
 Providing language training sessions for emulating the communication skills, group discussion techniques, and Interview techniques which are the screening methods used by the organizations these days.
 Developing a sound bond between industry and students by keeping up to the expectations of both.
 Conducting Model Aptitude tests, Mock Group discussions &amp; Mock Interviews to pinnacle in the Recruitment process.
 Continuously updating the database for meeting the different requirements from the organisations and to make students choose the best possible company for their career.
 Updating various departments about the requirements of the industry so as to enable them to get the students ready for the external world.
 In-plant training, Industrial visits, Projects, Guest lectures and other Industry-Institute interaction activities.
 Arranging meeting with eminent personalities from the industry so as to emphasis the ever changing need of the industry and how to make one ready for it.
 Arranging Entrepreneurship Guidance Programmes.
 Career guidance sessions for higher studies.
 Arranging – Industry Institute partnership.
 
 
 ')]</value>
      <webElementGuid>4faede80-4c12-42eb-a180-d6f5db54ec06</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
