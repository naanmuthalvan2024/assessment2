<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Providing language training sessions for_a64c5b</name>
   <tag></tag>
   <elementGuidId>5bf5f8a2-6c2c-4b48-ba79-72f6558784f2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/section[7]/div/div/div/div[2]/div/ol/li</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-5020bf5.elementor-widget.elementor-widget-text-editor > div.elementor-widget-container > ol > li</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Providing language training sessions for emulating the communication skills, gro&quot;i >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>a35af0ec-7fb5-4731-ad3a-79866e359c8d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Providing language training sessions for emulating the communication skills, group discussion techniques, and Interview techniques which are the screening methods used by the organizations these days.</value>
      <webElementGuid>62be26a5-8f67-4cc9-b18f-138eaa19c49d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/section[@class=&quot;elementor-section elementor-top-section elementor-element elementor-element-accaccb elementor-section-boxed elementor-section-height-default elementor-section-height-default&quot;]/div[@class=&quot;elementor-container elementor-column-gap-default&quot;]/div[@class=&quot;elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5240834&quot;]/div[@class=&quot;elementor-widget-wrap elementor-element-populated&quot;]/div[@class=&quot;elementor-element elementor-element-5020bf5 elementor-widget elementor-widget-text-editor&quot;]/div[@class=&quot;elementor-widget-container&quot;]/ol[1]/li[1]</value>
      <webElementGuid>fe515190-675e-458c-a691-e14deb8aec95</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/section[7]/div/div/div/div[2]/div/ol/li</value>
      <webElementGuid>28e85275-7870-40eb-978e-d1dd8ea85756</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Activity'])[1]/following::li[1]</value>
      <webElementGuid>6866e57e-149e-4d69-9e4d-675382bd45e8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Entrepreneurship Development and Innovation Institute'])[1]/following::li[1]</value>
      <webElementGuid>b2ab110a-9a97-47d8-8523-96f4d525cf08</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Developing a sound bond between industry and students by keeping up to the expectations of both.'])[1]/preceding::li[1]</value>
      <webElementGuid>fca71e0d-9245-458a-8156-1ee4e03d713a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Arranging Entrepreneurship Guidance Programmes.'])[1]/preceding::li[7]</value>
      <webElementGuid>1ebed325-af55-414c-998c-d05a2cc1c8d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Providing language training sessions for emulating the communication skills, group discussion techniques, and Interview techniques which are the screening methods used by the organizations these days.']/parent::*</value>
      <webElementGuid>0e9beacd-ec74-4d24-aadb-04737601cfe4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/ol/li</value>
      <webElementGuid>a819af22-d800-42ac-8543-e6e76ccd38ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = 'Providing language training sessions for emulating the communication skills, group discussion techniques, and Interview techniques which are the screening methods used by the organizations these days.' or . = 'Providing language training sessions for emulating the communication skills, group discussion techniques, and Interview techniques which are the screening methods used by the organizations these days.')]</value>
      <webElementGuid>f555f383-5464-47b8-9417-ce8272501004</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
