<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_ELIGIBILITY  CRITERIA</name>
   <tag></tag>
   <elementGuidId>563e6c50-9826-49b9-ad94-27d01c238fee</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[4]/ul/li[3]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;ELIGIBILITY &amp; CRITERIA&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>0695e32f-9a9b-43a2-b55e-2d0c9f20a230</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/eligibility--criteria</value>
      <webElementGuid>61033256-7fea-4534-8c05-153fe8121d34</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>ELIGIBILITY &amp; CRITERIA</value>
      <webElementGuid>69bde0b0-f527-4364-aca9-2185385c03e2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[3]/a[1]</value>
      <webElementGuid>6e4c2a4b-f101-42df-a436-4294227d5980</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[4]/ul/li[3]/a</value>
      <webElementGuid>47e4e0f6-bff7-44c8-be64-dc22cb822615</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'ELIGIBILITY &amp; CRITERIA')]</value>
      <webElementGuid>c44e6dc5-4f0a-4ed2-a346-d39232b20eba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PROSPECT US'])[2]/following::a[1]</value>
      <webElementGuid>d9756a71-a6b4-4763-bd56-743b3ee39058</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ONLINE APPLICATION'])[1]/following::a[2]</value>
      <webElementGuid>132640b5-3fc7-415e-a932-d78d1ec8796d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Students Life'])[1]/preceding::a[1]</value>
      <webElementGuid>967197b0-7ee8-4e65-9b8c-cba3221aad08</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Placement'])[1]/preceding::a[2]</value>
      <webElementGuid>d266aa2f-79c6-40a9-9b18-cc4486c31328</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='ELIGIBILITY &amp; CRITERIA']/parent::*</value>
      <webElementGuid>402f9159-8bf9-47a4-8265-b39b0f9051c2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/eligibility--criteria')]</value>
      <webElementGuid>eed0b726-bc2b-442b-bebe-8879e6836ae9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[4]/ul/li[3]/a</value>
      <webElementGuid>3fe60efb-e3b0-414a-867a-3ada71c8b21e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/eligibility--criteria' and (text() = 'ELIGIBILITY &amp; CRITERIA' or . = 'ELIGIBILITY &amp; CRITERIA')]</value>
      <webElementGuid>7307e347-d4d1-4aa4-86ab-e1611604321f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
