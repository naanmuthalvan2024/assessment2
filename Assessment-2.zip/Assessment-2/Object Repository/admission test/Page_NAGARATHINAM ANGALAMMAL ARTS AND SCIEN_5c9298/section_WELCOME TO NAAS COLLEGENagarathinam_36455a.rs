<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>section_WELCOME TO NAAS COLLEGENagarathinam_36455a</name>
   <tag></tag>
   <elementGuidId>885a000c-1416-451b-857f-8b06619c9b2b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>section.py-4.about_bg.mb-4</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>section >> internal:has-text=&quot;WELCOME TO NAAS COLLEGENagarathinam Angalammal Arts &amp; Science College establishe&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>section</value>
      <webElementGuid>aa61271b-f35a-40c3-8b74-c2608275e71e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>py-4 about_bg mb-4</value>
      <webElementGuid>f96921f0-778d-4693-b806-8a0702db3a78</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>WELCOME TO NAAS COLLEGENagarathinam Angalammal Arts &amp; Science College established in the Academic year 2018. The college is the meticulously managed by the Nagarathinam Angalammal Educational Trust with the primary aim of education to the people of the rural areas who have a dream for good and higher education at reasonable cost. This college is purely self-finance and the Co-educational institution. The motto of the college is “Lead to lluminate&quot; This premier institution is run entirely as a non-profit one. Admission is purely on merit basis. ReadMore...</value>
      <webElementGuid>940a4196-2d3e-44d2-be87-9e3224e630aa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[@class=&quot;py-4 about_bg mb-4&quot;]</value>
      <webElementGuid>9081789e-4a36-46a5-8667-f1817201a82d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]</value>
      <webElementGuid>3b49b744-65c0-4ef0-bff9-34a023d43eed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Next'])[1]/following::section[2]</value>
      <webElementGuid>802b6e91-8f52-4f8c-9675-2d90f482f49b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Previous'])[1]/following::section[2]</value>
      <webElementGuid>28adb7fa-d8e6-4ebc-9527-98377f9b3af7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[2]</value>
      <webElementGuid>672aa070-5134-4eaa-a206-05d673db5fed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//section[(text() = 'WELCOME TO NAAS COLLEGENagarathinam Angalammal Arts &amp; Science College established in the Academic year 2018. The college is the meticulously managed by the Nagarathinam Angalammal Educational Trust with the primary aim of education to the people of the rural areas who have a dream for good and higher education at reasonable cost. This college is purely self-finance and the Co-educational institution. The motto of the college is “Lead to lluminate&quot; This premier institution is run entirely as a non-profit one. Admission is purely on merit basis. ReadMore...' or . = 'WELCOME TO NAAS COLLEGENagarathinam Angalammal Arts &amp; Science College established in the Academic year 2018. The college is the meticulously managed by the Nagarathinam Angalammal Educational Trust with the primary aim of education to the people of the rural areas who have a dream for good and higher education at reasonable cost. This college is purely self-finance and the Co-educational institution. The motto of the college is “Lead to lluminate&quot; This premier institution is run entirely as a non-profit one. Admission is purely on merit basis. ReadMore...')]</value>
      <webElementGuid>8987091b-5902-4683-9884-725a253b28ef</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
