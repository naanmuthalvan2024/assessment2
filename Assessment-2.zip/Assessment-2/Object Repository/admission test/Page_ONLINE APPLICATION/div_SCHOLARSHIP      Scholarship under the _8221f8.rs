<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_SCHOLARSHIP      Scholarship under the _8221f8</name>
   <tag></tag>
   <elementGuidId>443a26d8-da80-4b3c-aeb2-196b6322bb0c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/section[2]/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.elementor-column.elementor-col-100.elementor-inner-column.elementor-element.elementor-element-93ad098 > div.elementor-widget-wrap.elementor-element-populated</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;SCHOLARSHIP ; Scholarship under the following schemes: Management scholarship fo&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>77e3e054-fab1-4b66-86bd-e9890c9fdd05</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-widget-wrap elementor-element-populated</value>
      <webElementGuid>13aa0b9e-bed5-4ffc-98ac-f3c2e279d9f4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
 
 
 SCHOLARSHIP ;
 
 
 
 
 Scholarship under the following schemes:
 
 Management scholarship for the deserving meritorious students.
 SC/ST Scholarship given by Tamil Nadu Government.
 Farmer Welfare Scheme scholarship given by Tamil Nadu Government
 
 
 
 
 
 
 
 
 
 
 
 
 ATTESTATION OF THE APPLICANT ;
 
 
 
 
 
 Applicants can self-attest the marks entry in the application forms.
 The candidate is informed that after proper scrutiny of his/her mark statement,if found that the marks furnished by him/her in the application form are not correct then following actions will be taken by the Principal immediately without any compromise.
 He/she will be forfeited the admission no matter at what stage of course he/she will be in at that time.
 Legal action will be taken against him/her for furnishing wrong information.
 
 
 
 
 
 Apply Now
 
 
 </value>
      <webElementGuid>ff8f5d21-c78b-4887-8ac8-2c97da71c0a2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/section[@class=&quot;elementor-section elementor-inner-section elementor-element elementor-element-6ae7e5a elementor-section-boxed elementor-section-height-default elementor-section-height-default&quot;]/div[@class=&quot;elementor-container elementor-column-gap-default&quot;]/div[@class=&quot;elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-93ad098&quot;]/div[@class=&quot;elementor-widget-wrap elementor-element-populated&quot;]</value>
      <webElementGuid>b3240fd6-f739-4e22-94df-d2456b0b2262</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/section[2]/div/div/div</value>
      <webElementGuid>bd141fdc-b30f-4ecb-bcd4-4ab59fa46d2c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Other country/state students have to provide Eligibility certificate from their state government.'])[1]/following::div[3]</value>
      <webElementGuid>66939112-611b-4e85-bcfb-489865c8549a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Certificate of proof for the differently abled / Sports/ NCC/ Ex-servicemen etc., if any.'])[1]/following::div[3]</value>
      <webElementGuid>c606182b-b918-408c-a8d5-3951e59f437a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/section[2]/div/div/div</value>
      <webElementGuid>ccec607c-5ce9-40fc-8537-7a30f17e7b29</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
 
 
 SCHOLARSHIP ;
 
 
 
 
 Scholarship under the following schemes:
 
 Management scholarship for the deserving meritorious students.
 SC/ST Scholarship given by Tamil Nadu Government.
 Farmer Welfare Scheme scholarship given by Tamil Nadu Government
 
 
 
 
 
 
 
 
 
 
 
 
 ATTESTATION OF THE APPLICANT ;
 
 
 
 
 
 Applicants can self-attest the marks entry in the application forms.
 The candidate is informed that after proper scrutiny of his/her mark statement,if found that the marks furnished by him/her in the application form are not correct then following actions will be taken by the Principal immediately without any compromise.
 He/she will be forfeited the admission no matter at what stage of course he/she will be in at that time.
 Legal action will be taken against him/her for furnishing wrong information.
 
 
 
 
 
 Apply Now
 
 
 ' or . = '
 
 
 SCHOLARSHIP ;
 
 
 
 
 Scholarship under the following schemes:
 
 Management scholarship for the deserving meritorious students.
 SC/ST Scholarship given by Tamil Nadu Government.
 Farmer Welfare Scheme scholarship given by Tamil Nadu Government
 
 
 
 
 
 
 
 
 
 
 
 
 ATTESTATION OF THE APPLICANT ;
 
 
 
 
 
 Applicants can self-attest the marks entry in the application forms.
 The candidate is informed that after proper scrutiny of his/her mark statement,if found that the marks furnished by him/her in the application form are not correct then following actions will be taken by the Principal immediately without any compromise.
 He/she will be forfeited the admission no matter at what stage of course he/she will be in at that time.
 Legal action will be taken against him/her for furnishing wrong information.
 
 
 
 
 
 Apply Now
 
 
 ')]</value>
      <webElementGuid>402a2b38-daff-4bed-a6a1-af53192ea33d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
