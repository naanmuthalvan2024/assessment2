<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h5_SCHOLARSHIP</name>
   <tag></tag>
   <elementGuidId>594e9a0a-bdbe-4c87-8907-2718e0afbc75</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/section[2]/div/div/div/div/div/h5</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-5b860aa.elementor-widget.elementor-widget-heading > div.elementor-widget-container > h5.elementor-heading-title.elementor-size-default</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;SCHOLARSHIP ;&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h5</value>
      <webElementGuid>fa197055-c03d-4cd6-a0c9-18978f8ee33f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-heading-title elementor-size-default</value>
      <webElementGuid>2bd0e824-a3b7-42b1-9fe2-644de5ebf960</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>SCHOLARSHIP ;</value>
      <webElementGuid>0adca89e-b068-425a-9fba-ba349520e512</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/section[@class=&quot;elementor-section elementor-inner-section elementor-element elementor-element-6ae7e5a elementor-section-boxed elementor-section-height-default elementor-section-height-default&quot;]/div[@class=&quot;elementor-container elementor-column-gap-default&quot;]/div[@class=&quot;elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-93ad098&quot;]/div[@class=&quot;elementor-widget-wrap elementor-element-populated&quot;]/div[@class=&quot;elementor-element elementor-element-5b860aa elementor-widget elementor-widget-heading&quot;]/div[@class=&quot;elementor-widget-container&quot;]/h5[@class=&quot;elementor-heading-title elementor-size-default&quot;]</value>
      <webElementGuid>3673ef2a-7ec4-4748-9dde-29a6759e42a4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/section[2]/div/div/div/div/div/h5</value>
      <webElementGuid>a3def339-c249-4760-8c10-5760afbb3789</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Other country/state students have to provide Eligibility certificate from their state government.'])[1]/following::h5[1]</value>
      <webElementGuid>9c3de9d7-ae24-4dce-afa9-15453daa13c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Certificate of proof for the differently abled / Sports/ NCC/ Ex-servicemen etc., if any.'])[1]/following::h5[1]</value>
      <webElementGuid>a91580b8-932b-492b-9c4a-39c45f70f42e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Scholarship under the following schemes:'])[1]/preceding::h5[1]</value>
      <webElementGuid>45c5d4b0-0891-4239-b0d2-791d521335ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Management scholarship for the deserving meritorious students.'])[1]/preceding::h5[1]</value>
      <webElementGuid>a552b25d-1a7f-4aca-a9e0-9f2ee43b190e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='SCHOLARSHIP ;']/parent::*</value>
      <webElementGuid>d546a197-f308-448b-ba1a-b62e363c4e03</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[2]/div/div/div/div/div/h5</value>
      <webElementGuid>8c282fc7-4953-479e-947c-79328c8fe568</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h5[(text() = 'SCHOLARSHIP ;' or . = 'SCHOLARSHIP ;')]</value>
      <webElementGuid>41f37b5f-9cd1-402c-8cf5-623148e91d9c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
