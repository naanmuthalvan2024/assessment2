<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_ONLINE APPLICATION</name>
   <tag></tag>
   <elementGuidId>88bab87f-b808-4cdb-977f-51a469423a97</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section/div/div/div/h1</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h1</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;ONLINE APPLICATION&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>fe5c5804-dc2f-4c13-91a6-762f151271ae</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>ONLINE APPLICATION</value>
      <webElementGuid>6b75da61-8d78-4682-9da8-cb6ed4b0887d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[1]/div[@class=&quot;head-2&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;head-2-inn head-2-inn-padd-top&quot;]/h1[1]</value>
      <webElementGuid>9063c444-ff35-4d68-80ea-65000b00c3b1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section/div/div/div/h1</value>
      <webElementGuid>82665f86-4b9d-4b22-8d56-baf9805a64a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gallery'])[1]/following::h1[1]</value>
      <webElementGuid>a1e685cc-906b-4953-94d2-6efed8e6b8ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NIRF'])[1]/following::h1[1]</value>
      <webElementGuid>ca88dd65-832a-4b96-bca3-357f1a496e70</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NAAS ADMISSION PROCEDURE'])[1]/preceding::h1[1]</value>
      <webElementGuid>85e99aa9-dee1-4869-8fad-e1a10acee924</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Application /Registration is available via both online and offline modes.'])[1]/preceding::h1[1]</value>
      <webElementGuid>e13efd05-4e2b-49a6-8b6a-97f91d1a5046</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>1cff45e0-1690-4fb5-9c17-d46ef158ce80</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = 'ONLINE APPLICATION' or . = 'ONLINE APPLICATION')]</value>
      <webElementGuid>1abe207f-74ea-42fe-a94b-b0f1a3946c33</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
