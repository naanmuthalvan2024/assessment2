<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Education is a prerequisite to progress_321656</name>
   <tag></tag>
   <elementGuidId>fc75f9a5-b651-4c60-8213-4e037d07c4b1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/section[9]/div/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-76ecbc3.elementor-widget.elementor-widget-text-editor</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>section:nth-child(9) > .elementor-container > div > .elementor-widget-wrap > .elementor-element >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>176c46cd-bf6a-4e1b-88c1-764ab6596339</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-element elementor-element-76ecbc3 elementor-widget elementor-widget-text-editor</value>
      <webElementGuid>8222256b-d139-492c-9972-b2351324486f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-id</name>
      <type>Main</type>
      <value>76ecbc3</value>
      <webElementGuid>f27a5624-f11f-489e-a6bd-46fc7f7c883d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-element_type</name>
      <type>Main</type>
      <value>widget</value>
      <webElementGuid>cdca7105-6493-4151-994d-1bc97ddb64a4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-widget_type</name>
      <type>Main</type>
      <value>text-editor.default</value>
      <webElementGuid>e0837bb1-d020-4ecb-8ced-53bb371e436f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
 
 Education is a prerequisite to progress and development of a Society.Nagarathinam Angalammal Arts &amp; Science (NAAS) College was started in the year 2018 with an aim of imparting quality education at affordable cost especially to the rural and downtrodden student community with a team of highly experienced and committed teachers.
 NAAS College is a trend setter for youngsters and it equips them to design their career growth. It endorses and nurtures the potential of every individual to the extent of perfection. It offers a wide array of academic programs and provides a better learning environment for students and faculty members. Apart from academics we encourage value added courses to find suitable jobs for our students.
 
 </value>
      <webElementGuid>ce1a0000-b22a-4f62-b77a-7c2b11fb0156</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/section[@class=&quot;elementor-section elementor-top-section elementor-element elementor-element-139a041 elementor-section-boxed elementor-section-height-default elementor-section-height-default&quot;]/div[@class=&quot;elementor-container elementor-column-gap-default&quot;]/div[@class=&quot;elementor-column elementor-col-66 elementor-top-column elementor-element elementor-element-3724dfa&quot;]/div[@class=&quot;elementor-widget-wrap elementor-element-populated&quot;]/div[@class=&quot;elementor-element elementor-element-76ecbc3 elementor-widget elementor-widget-text-editor&quot;]</value>
      <webElementGuid>3e9c4773-c4ba-4284-9289-fff184aff597</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/section[9]/div/div/div/div</value>
      <webElementGuid>8f1dffcd-d789-4061-930d-b38dd9f8446f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Secretary &amp; Correspondent'])[2]/following::div[4]</value>
      <webElementGuid>9fb773a6-51d5-4a64-83fc-85e72d3facdf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='M.Com.,B.L.,Ph.D.,'])[1]/following::div[6]</value>
      <webElementGuid>481fd837-1931-460c-8777-a3ba7e788326</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='“Lead to Illuminate”'])[1]/preceding::div[6]</value>
      <webElementGuid>c886b1e8-fdf8-499e-8c1b-321803ec4a02</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About Us'])[2]/preceding::div[12]</value>
      <webElementGuid>4b5c5789-59be-4420-96ff-063ac4732a07</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[9]/div/div/div/div</value>
      <webElementGuid>c37d726b-b605-4aa1-b077-b9b82483d411</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
 
 Education is a prerequisite to progress and development of a Society.Nagarathinam Angalammal Arts &amp; Science (NAAS) College was started in the year 2018 with an aim of imparting quality education at affordable cost especially to the rural and downtrodden student community with a team of highly experienced and committed teachers.
 NAAS College is a trend setter for youngsters and it equips them to design their career growth. It endorses and nurtures the potential of every individual to the extent of perfection. It offers a wide array of academic programs and provides a better learning environment for students and faculty members. Apart from academics we encourage value added courses to find suitable jobs for our students.
 
 ' or . = '
 
 Education is a prerequisite to progress and development of a Society.Nagarathinam Angalammal Arts &amp; Science (NAAS) College was started in the year 2018 with an aim of imparting quality education at affordable cost especially to the rural and downtrodden student community with a team of highly experienced and committed teachers.
 NAAS College is a trend setter for youngsters and it equips them to design their career growth. It endorses and nurtures the potential of every individual to the extent of perfection. It offers a wide array of academic programs and provides a better learning environment for students and faculty members. Apart from academics we encourage value added courses to find suitable jobs for our students.
 
 ')]</value>
      <webElementGuid>4c51dba7-b516-470d-b0c6-4c14df266000</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
