<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_STUDENTS LIFE</name>
   <tag></tag>
   <elementGuidId>1f6fe7ea-3eea-461b-83e5-b393baa29af6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section/div/div/div/div[3]/ul/li[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(2) > a.fw-bold</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot; STUDENTS LIFE&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>21abc432-8aba-41dc-95af-660f73509691</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>students-life</value>
      <webElementGuid>e987f620-3127-44d1-bc5b-d145348baaeb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fw-bold</value>
      <webElementGuid>f50c6fa7-8cae-4227-ac4c-caced0f5814f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>STUDENTS LIFE</value>
      <webElementGuid>8c836d9f-fc4a-462f-83b3-16fa24ed3f20</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[@class=&quot;theme-bg-dark footer&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;wed-foot-link&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-2 col-6&quot;]/ul[@class=&quot;mt-3&quot;]/li[2]/a[@class=&quot;fw-bold&quot;]</value>
      <webElementGuid>bdc1c1f0-2501-46cf-9d92-15f810bbc981</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section/div/div/div/div[3]/ul/li[2]/a</value>
      <webElementGuid>07405713-b872-4448-91d5-c463cea6ff36</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'STUDENTS LIFE')]</value>
      <webElementGuid>e0876d0b-b17b-4e68-baaa-e1fd74d9a694</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home'])[2]/following::a[1]</value>
      <webElementGuid>176fb969-1780-4cd8-aace-d4de67c276f6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Quick Links'])[1]/following::a[2]</value>
      <webElementGuid>f9f701db-b19c-4522-aa5d-0f0ce5992cbf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='DEPARTMENTS'])[1]/preceding::a[1]</value>
      <webElementGuid>f84c300b-9f33-4be1-a45e-0067b0d74b0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PROSPECTUS'])[1]/preceding::a[2]</value>
      <webElementGuid>6c47170e-b138-4fee-b205-d4c1d918b40c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='STUDENTS LIFE']/parent::*</value>
      <webElementGuid>0e3a81f6-8c61-4457-a311-1046c02856bc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'students-life')])[2]</value>
      <webElementGuid>ee1e7d22-b747-4c63-b507-9cd77ff62dac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/ul/li[2]/a</value>
      <webElementGuid>f000fdb2-f33e-4b18-bc1b-86494a0c0ff3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'students-life' and (text() = 'STUDENTS LIFE' or . = 'STUDENTS LIFE')]</value>
      <webElementGuid>44be9e54-0f08-48b1-8d77-dd0170ac33bc</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
