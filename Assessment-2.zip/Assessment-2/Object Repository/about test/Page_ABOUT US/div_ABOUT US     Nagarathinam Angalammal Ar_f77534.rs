<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_ABOUT US     Nagarathinam Angalammal Ar_f77534</name>
   <tag></tag>
   <elementGuidId>98911c42-b519-4398-86d1-1deac70832a6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-md-12</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>.col-md-12 >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>b60900bf-9c6f-48b8-8261-b5fea8d89c5a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-md-12</value>
      <webElementGuid>2a5b9ad1-1d99-4da9-b368-d88cd8edbf5a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
 
 
 
 
 
 ABOUT US
 
 
 
 
 Nagarathinam Angalammal Arts &amp; Science College was founded in the Academic year 2018. The college is meticulously managed by the Nagarathinam Angalammal Educational Trust with the primary aim of education to the most people of the rural areas who have a dream for good and higher education t a reasonable cost. This college is purely self finance and co educational institution. The motto of the college is “ lead to illuminate” This premier institution is run entirely as a non profit institution. Admission are purely on merit basis.
 
 
 
 
 
 
 
 
 
 
 
 


 
 
 
 
 
 MANAGEMENT
 
 
 
 
 


 
 
 
 
 
 
 
 
 Dr.S.Nagarathinam
 
 
 
 
 Chairman
 
 
 
 
 
 
 
 
 
 
 
 Dr.N.Jegatheesan
 
 
 
 
 Secretary &amp; Correspondent
 
 
 
 
 
 
 
 
 
 
 
 N.Rajendiran
 
 
 
 
 Managing Trustee
 
 
 
 
 
 
 
 
 
 
 
 N.karthikeyan
 
 
 
 
 Managing Trustee
 
 
 
 
 


 
 
 
 
 
 
 
 
 
 
 
 
 


 
 
 
 
 
 Dr. S. Nagarathinam
 
 
 
 
 Chairman
 
 
 
 
 


 
 
 
 
 
 
 
 
 
 
 
 
 Nagarathinam Angalammal Educational Trust is much pleased to establish an Arts &amp; Science College by name “Nagarathinam Angalammal Arts &amp; Science College” with an aim to provide excellent education packed with intellectual development at affordable cost to the youngsters who come to pursue education with high ambitions. The college was located at a comfortable well connected place, equipped with state-of-the art facilities along with well experienced, qualified and dedicated staff.
 A well defined vision, highly committed mission and dedicated leadership facilitate the college to be one among the best of educational institutions in Madurai and to achieve both academic and personal goals of the students community. I extend my cordial felicitations to the Principal, faculty, non teaching staff and the students of our college for making our humble project a grand success.
 
 
 
 
 


 
 
 
 
 
 
 
 
 
 
 
 
 


 
 
 
 
 
 
 
 
 
 Dr.N.JegatheesanM.Com.,B.L.,Ph.D.,
 
 
 
 
 
 
 
 
 Secretary &amp; Correspondent
 
 
 
 
 


 
 
 
 
 
 Education is a prerequisite to progress and development of a Society.Nagarathinam Angalammal Arts &amp; Science (NAAS) College was started in the year 2018 with an aim of imparting quality education at affordable cost especially to the rural and downtrodden student community with a team of highly experienced and committed teachers.
 NAAS College is a trend setter for youngsters and it equips them to design their career growth. It endorses and nurtures the potential of every individual to the extent of perfection. It offers a wide array of academic programs and provides a better learning environment for students and faculty members. Apart from academics we encourage value added courses to find suitable jobs for our students.
 
 
 
 
 
 
 
 
 
 
 
 


 
 
 
 
 
 NAAS College’s focus is on all round development and it fosters intellectual and personal development. It creates an atmosphere to impart quality education in a healthy environment where curricular, co-curricular and extra curricular facilities mould the young minds and motivate them to be the brightest and the best.
 To mould many young minds especially from villages towards excellence through education Nagarathinam Angalammal Educational Trust started this College with the motto of “Lead to Illuminate”.
 I appreciate and congratulate all the efforts made by the Principal, Teaching, Non-Teaching and support staff members.
 
 
 
 
 
</value>
      <webElementGuid>c9b8f52c-7aa7-430e-a41c-2c49042ddf0d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]</value>
      <webElementGuid>2df23d2e-3824-40d0-95f4-72727e6953d0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div</value>
      <webElementGuid>f5059cd7-b9ca-4719-9133-280db1e7d5ee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ABOUT US'])[2]/following::div[3]</value>
      <webElementGuid>fa773fce-0c17-4ee1-8fe2-4bb6185213e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gallery'])[1]/following::div[12]</value>
      <webElementGuid>491f460e-fa3e-412c-a6ad-c984963002a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[2]/div/div/div</value>
      <webElementGuid>4fff607c-2162-40d5-8df2-5987f86dfc83</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
 
 
 
 
 
 ABOUT US
 
 
 
 
 Nagarathinam Angalammal Arts &amp; Science College was founded in the Academic year 2018. The college is meticulously managed by the Nagarathinam Angalammal Educational Trust with the primary aim of education to the most people of the rural areas who have a dream for good and higher education t a reasonable cost. This college is purely self finance and co educational institution. The motto of the college is “ lead to illuminate” This premier institution is run entirely as a non profit institution. Admission are purely on merit basis.
 
 
 
 
 
 
 
 
 
 
 
 


 
 
 
 
 
 MANAGEMENT
 
 
 
 
 


 
 
 
 
 
 
 
 
 Dr.S.Nagarathinam
 
 
 
 
 Chairman
 
 
 
 
 
 
 
 
 
 
 
 Dr.N.Jegatheesan
 
 
 
 
 Secretary &amp; Correspondent
 
 
 
 
 
 
 
 
 
 
 
 N.Rajendiran
 
 
 
 
 Managing Trustee
 
 
 
 
 
 
 
 
 
 
 
 N.karthikeyan
 
 
 
 
 Managing Trustee
 
 
 
 
 


 
 
 
 
 
 
 
 
 
 
 
 
 


 
 
 
 
 
 Dr. S. Nagarathinam
 
 
 
 
 Chairman
 
 
 
 
 


 
 
 
 
 
 
 
 
 
 
 
 
 Nagarathinam Angalammal Educational Trust is much pleased to establish an Arts &amp; Science College by name “Nagarathinam Angalammal Arts &amp; Science College” with an aim to provide excellent education packed with intellectual development at affordable cost to the youngsters who come to pursue education with high ambitions. The college was located at a comfortable well connected place, equipped with state-of-the art facilities along with well experienced, qualified and dedicated staff.
 A well defined vision, highly committed mission and dedicated leadership facilitate the college to be one among the best of educational institutions in Madurai and to achieve both academic and personal goals of the students community. I extend my cordial felicitations to the Principal, faculty, non teaching staff and the students of our college for making our humble project a grand success.
 
 
 
 
 


 
 
 
 
 
 
 
 
 
 
 
 
 


 
 
 
 
 
 
 
 
 
 Dr.N.JegatheesanM.Com.,B.L.,Ph.D.,
 
 
 
 
 
 
 
 
 Secretary &amp; Correspondent
 
 
 
 
 


 
 
 
 
 
 Education is a prerequisite to progress and development of a Society.Nagarathinam Angalammal Arts &amp; Science (NAAS) College was started in the year 2018 with an aim of imparting quality education at affordable cost especially to the rural and downtrodden student community with a team of highly experienced and committed teachers.
 NAAS College is a trend setter for youngsters and it equips them to design their career growth. It endorses and nurtures the potential of every individual to the extent of perfection. It offers a wide array of academic programs and provides a better learning environment for students and faculty members. Apart from academics we encourage value added courses to find suitable jobs for our students.
 
 
 
 
 
 
 
 
 
 
 
 


 
 
 
 
 
 NAAS College’s focus is on all round development and it fosters intellectual and personal development. It creates an atmosphere to impart quality education in a healthy environment where curricular, co-curricular and extra curricular facilities mould the young minds and motivate them to be the brightest and the best.
 To mould many young minds especially from villages towards excellence through education Nagarathinam Angalammal Educational Trust started this College with the motto of “Lead to Illuminate”.
 I appreciate and congratulate all the efforts made by the Principal, Teaching, Non-Teaching and support staff members.
 
 
 
 
 
' or . = '
 
 
 
 
 
 ABOUT US
 
 
 
 
 Nagarathinam Angalammal Arts &amp; Science College was founded in the Academic year 2018. The college is meticulously managed by the Nagarathinam Angalammal Educational Trust with the primary aim of education to the most people of the rural areas who have a dream for good and higher education t a reasonable cost. This college is purely self finance and co educational institution. The motto of the college is “ lead to illuminate” This premier institution is run entirely as a non profit institution. Admission are purely on merit basis.
 
 
 
 
 
 
 
 
 
 
 
 


 
 
 
 
 
 MANAGEMENT
 
 
 
 
 


 
 
 
 
 
 
 
 
 Dr.S.Nagarathinam
 
 
 
 
 Chairman
 
 
 
 
 
 
 
 
 
 
 
 Dr.N.Jegatheesan
 
 
 
 
 Secretary &amp; Correspondent
 
 
 
 
 
 
 
 
 
 
 
 N.Rajendiran
 
 
 
 
 Managing Trustee
 
 
 
 
 
 
 
 
 
 
 
 N.karthikeyan
 
 
 
 
 Managing Trustee
 
 
 
 
 


 
 
 
 
 
 
 
 
 
 
 
 
 


 
 
 
 
 
 Dr. S. Nagarathinam
 
 
 
 
 Chairman
 
 
 
 
 


 
 
 
 
 
 
 
 
 
 
 
 
 Nagarathinam Angalammal Educational Trust is much pleased to establish an Arts &amp; Science College by name “Nagarathinam Angalammal Arts &amp; Science College” with an aim to provide excellent education packed with intellectual development at affordable cost to the youngsters who come to pursue education with high ambitions. The college was located at a comfortable well connected place, equipped with state-of-the art facilities along with well experienced, qualified and dedicated staff.
 A well defined vision, highly committed mission and dedicated leadership facilitate the college to be one among the best of educational institutions in Madurai and to achieve both academic and personal goals of the students community. I extend my cordial felicitations to the Principal, faculty, non teaching staff and the students of our college for making our humble project a grand success.
 
 
 
 
 


 
 
 
 
 
 
 
 
 
 
 
 
 


 
 
 
 
 
 
 
 
 
 Dr.N.JegatheesanM.Com.,B.L.,Ph.D.,
 
 
 
 
 
 
 
 
 Secretary &amp; Correspondent
 
 
 
 
 


 
 
 
 
 
 Education is a prerequisite to progress and development of a Society.Nagarathinam Angalammal Arts &amp; Science (NAAS) College was started in the year 2018 with an aim of imparting quality education at affordable cost especially to the rural and downtrodden student community with a team of highly experienced and committed teachers.
 NAAS College is a trend setter for youngsters and it equips them to design their career growth. It endorses and nurtures the potential of every individual to the extent of perfection. It offers a wide array of academic programs and provides a better learning environment for students and faculty members. Apart from academics we encourage value added courses to find suitable jobs for our students.
 
 
 
 
 
 
 
 
 
 
 
 


 
 
 
 
 
 NAAS College’s focus is on all round development and it fosters intellectual and personal development. It creates an atmosphere to impart quality education in a healthy environment where curricular, co-curricular and extra curricular facilities mould the young minds and motivate them to be the brightest and the best.
 To mould many young minds especially from villages towards excellence through education Nagarathinam Angalammal Educational Trust started this College with the motto of “Lead to Illuminate”.
 I appreciate and congratulate all the efforts made by the Principal, Teaching, Non-Teaching and support staff members.
 
 
 
 
 
')]</value>
      <webElementGuid>6ce852e3-dd6f-46e5-b99b-7b20a5e8e964</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
