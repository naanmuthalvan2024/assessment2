<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_NAAS College is a trend setter for youngs_ca0ecb</name>
   <tag></tag>
   <elementGuidId>22bb9870-f0de-485e-9d09-7428fc29c225</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/section[9]/div/div/div/div/div/p[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-76ecbc3.elementor-widget.elementor-widget-text-editor > div.elementor-widget-container > p:nth-of-type(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;NAAS College is a trend setter for youngsters and it equips them to design their&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>973894f4-cc70-477d-9081-d262cb3349f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>NAAS College is a trend setter for youngsters and it equips them to design their career growth. It endorses and nurtures the potential of every individual to the extent of perfection. It offers a wide array of academic programs and provides a better learning environment for students and faculty members. Apart from academics we encourage value added courses to find suitable jobs for our students.</value>
      <webElementGuid>79d46509-2e11-465c-9c2e-4554d1ebe3ec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/section[@class=&quot;elementor-section elementor-top-section elementor-element elementor-element-139a041 elementor-section-boxed elementor-section-height-default elementor-section-height-default&quot;]/div[@class=&quot;elementor-container elementor-column-gap-default&quot;]/div[@class=&quot;elementor-column elementor-col-66 elementor-top-column elementor-element elementor-element-3724dfa&quot;]/div[@class=&quot;elementor-widget-wrap elementor-element-populated&quot;]/div[@class=&quot;elementor-element elementor-element-76ecbc3 elementor-widget elementor-widget-text-editor&quot;]/div[@class=&quot;elementor-widget-container&quot;]/p[2]</value>
      <webElementGuid>e1bc883a-2a86-493c-ba91-23269dfa695a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/section[9]/div/div/div/div/div/p[2]</value>
      <webElementGuid>bfa33d4f-5191-43f0-8eee-fa968d1974e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Secretary &amp; Correspondent'])[2]/following::p[2]</value>
      <webElementGuid>0d25631b-612c-4a97-a9e0-a5773b927cd0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='M.Com.,B.L.,Ph.D.,'])[1]/following::p[2]</value>
      <webElementGuid>681c327d-bc8b-47eb-847d-e61567c0691c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='“Lead to Illuminate”'])[1]/preceding::p[2]</value>
      <webElementGuid>038390b2-c8dd-434e-8bdf-8c1a053369f3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About Us'])[2]/preceding::p[6]</value>
      <webElementGuid>ac826a8c-7682-41f3-adb5-e04dc9ebcc8d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='NAAS College is a trend setter for youngsters and it equips them to design their career growth. It endorses and nurtures the potential of every individual to the extent of perfection. It offers a wide array of academic programs and provides a better learning environment for students and faculty members. Apart from academics we encourage value added courses to find suitable jobs for our students.']/parent::*</value>
      <webElementGuid>33b97239-b893-470d-9fcb-f180719e1007</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[9]/div/div/div/div/div/p[2]</value>
      <webElementGuid>555726bb-e2ff-44ce-b31f-23d8ff9c457e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'NAAS College is a trend setter for youngsters and it equips them to design their career growth. It endorses and nurtures the potential of every individual to the extent of perfection. It offers a wide array of academic programs and provides a better learning environment for students and faculty members. Apart from academics we encourage value added courses to find suitable jobs for our students.' or . = 'NAAS College is a trend setter for youngsters and it equips them to design their career growth. It endorses and nurtures the potential of every individual to the extent of perfection. It offers a wide array of academic programs and provides a better learning environment for students and faculty members. Apart from academics we encourage value added courses to find suitable jobs for our students.')]</value>
      <webElementGuid>948a2d35-c360-4182-9a8c-bc1908f41e98</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
