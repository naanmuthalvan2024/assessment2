<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Nagarathinam Angalammal Arts  Science Col_23958f</name>
   <tag></tag>
   <elementGuidId>53a207e5-1b48-4179-ab4b-be1374bd8ea5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section/div/div/div/div[2]/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Nagarathinam Angalammal Arts &amp; Science College was founded in the year 2018. The&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>11315941-1853-40f0-b3fd-c7d0259e9ad6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Nagarathinam Angalammal Arts &amp; Science College was founded in the year 2018. The college is meticulously managed by the Nagarathinam Angalammal Educational Trust with the primary aim of education to the most people of the rural areas who have a dream for good and higher education at reasonable cost.</value>
      <webElementGuid>1c4fb057-ec36-44ae-a294-fe805eea1ded</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[@class=&quot;theme-bg-dark footer&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;wed-foot-link&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-3&quot;]/p[1]</value>
      <webElementGuid>e1497a6d-947f-4e1d-be28-9a47be5d195a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section/div/div/div/div[2]/p</value>
      <webElementGuid>ef843738-8159-42b2-aa03-fe5b901d3aec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About Us'])[2]/following::p[1]</value>
      <webElementGuid>6be93936-9eb8-4410-bc46-316819966506</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='“Lead to Illuminate”'])[1]/following::p[4]</value>
      <webElementGuid>2ae66e5b-a8e9-4934-b79f-7dad7b58fbc9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Quick Links'])[1]/preceding::p[1]</value>
      <webElementGuid>eccf8692-d553-4f1c-89e2-8ecdf8182a86</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home'])[2]/preceding::p[1]</value>
      <webElementGuid>ef547e5e-fefb-42b8-969f-83811989a34f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Nagarathinam Angalammal Arts &amp; Science College was founded in the year 2018. The college is meticulously managed by the Nagarathinam Angalammal Educational Trust with the primary aim of education to the most people of the rural areas who have a dream for good and higher education at reasonable cost.']/parent::*</value>
      <webElementGuid>fc6f4295-dc1b-4833-a128-40010068a993</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/p</value>
      <webElementGuid>82435340-14eb-4470-8646-5c1f844d839d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Nagarathinam Angalammal Arts &amp; Science College was founded in the year 2018. The college is meticulously managed by the Nagarathinam Angalammal Educational Trust with the primary aim of education to the most people of the rural areas who have a dream for good and higher education at reasonable cost.' or . = 'Nagarathinam Angalammal Arts &amp; Science College was founded in the year 2018. The college is meticulously managed by the Nagarathinam Angalammal Educational Trust with the primary aim of education to the most people of the rural areas who have a dream for good and higher education at reasonable cost.')]</value>
      <webElementGuid>e691ae7e-e831-4518-a48c-9d15108882b2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
