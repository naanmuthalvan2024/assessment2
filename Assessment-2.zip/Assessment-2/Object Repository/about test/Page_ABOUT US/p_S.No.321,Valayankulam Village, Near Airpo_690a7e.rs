<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_S.No.321,Valayankulam Village, Near Airpo_690a7e</name>
   <tag></tag>
   <elementGuidId>b186cc28-a3d5-4ce8-8bbb-a3b284405e24</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section/div/div/div/div/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-md-3 > p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;S.No.32/1,Valayankulam Village, Near Airport, Four way Track, Madurai- 625 022.&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>35d72372-3b61-4afb-830c-7347ac10ac26</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>S.No.32/1,Valayankulam Village, Near Airport, Four way Track, Madurai- 625 022.</value>
      <webElementGuid>af7d207b-931f-4fbc-8d5b-efc22b06a3d7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[@class=&quot;theme-bg-dark footer&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;wed-foot-link&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-3&quot;]/p[1]</value>
      <webElementGuid>ca079c01-a166-4e70-a7e2-759238c89a29</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section/div/div/div/div/p</value>
      <webElementGuid>594e4c0b-b914-47e1-b77c-773ad361ec3f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='“Lead to Illuminate”'])[1]/following::p[2]</value>
      <webElementGuid>c7dc4f7e-31d5-4961-abf5-a002235c8233</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Secretary &amp; Correspondent'])[2]/following::p[6]</value>
      <webElementGuid>3b06b8b6-ff3b-4db7-b833-384321c0ff51</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About Us'])[2]/preceding::p[2]</value>
      <webElementGuid>841cbc2d-ee32-450c-bd67-822a91775225</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Quick Links'])[1]/preceding::p[3]</value>
      <webElementGuid>274e9c88-e994-4430-9e80-2a158c91ace9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='S.No.32/1,Valayankulam Village, Near Airport, Four way Track, Madurai- 625 022.']/parent::*</value>
      <webElementGuid>a979bb3b-4863-4933-a12b-af814a924a12</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/div/div/div/p</value>
      <webElementGuid>f6723286-b0b4-4566-9785-059cd48b31e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'S.No.32/1,Valayankulam Village, Near Airport, Four way Track, Madurai- 625 022.' or . = 'S.No.32/1,Valayankulam Village, Near Airport, Four way Track, Madurai- 625 022.')]</value>
      <webElementGuid>6990fb68-434a-4e77-a2af-d9f9b150c808</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
