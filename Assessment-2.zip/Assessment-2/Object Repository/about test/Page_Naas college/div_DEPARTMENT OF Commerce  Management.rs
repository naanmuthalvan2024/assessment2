<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_DEPARTMENT OF Commerce  Management</name>
   <tag></tag>
   <elementGuidId>8349a578-9189-4fd2-8c65-bbb6eea25f75</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section[2]/div/div/div/a/div/div/div[2]/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.d-flex.justify-content-center.align-items-center</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;DEPARTMENT OF Commerce &amp; Management&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>ddd869d8-174b-43db-939c-c9101d5a2df2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>d-flex justify-content-center align-items-center</value>
      <webElementGuid>cbfc6c0c-1803-43ed-ad1b-e32cce0fd4e4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>DEPARTMENT OF Commerce &amp; Management</value>
      <webElementGuid>101c07b0-ca53-4457-be56-a2e18db07a8b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[2]/div[@class=&quot;container pg-inn ps_min_height&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;mb-4 col-md-4&quot;]/a[1]/div[@class=&quot;home-top-cour py-0&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;fw-bold text-dark col-md-8 col-8&quot;]/div[@class=&quot;d-flex justify-content-center align-items-center&quot;]</value>
      <webElementGuid>a87a1329-8b70-4ccd-b4dc-b29347753d94</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section[2]/div/div/div/a/div/div/div[2]/div</value>
      <webElementGuid>b12eaf48-aa5d-44e1-bf9e-c248620a9927</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Departments'])[2]/following::div[9]</value>
      <webElementGuid>27ee8900-9a45-4584-b6d3-3b775b22027a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gallery'])[1]/following::div[17]</value>
      <webElementGuid>f47d00a0-41d9-4a70-b5ce-409827306f51</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='DEPARTMENT OF']/parent::*</value>
      <webElementGuid>77a2970e-7660-4fc1-8390-db80b76cc801</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a/div/div/div[2]/div</value>
      <webElementGuid>67c11f33-e115-41bd-9049-a2e2102e45ba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'DEPARTMENT OF Commerce &amp; Management' or . = 'DEPARTMENT OF Commerce &amp; Management')]</value>
      <webElementGuid>b46376af-7893-4035-a935-80c040120e05</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
