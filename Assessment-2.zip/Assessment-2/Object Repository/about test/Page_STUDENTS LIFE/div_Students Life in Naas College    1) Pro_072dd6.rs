<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Students Life in Naas College    1) Pro_072dd6</name>
   <tag></tag>
   <elementGuidId>b12d4f64-3407-44ee-914f-0485e846211a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-md-12 > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Students Life in Naas College 1) Professional Playground with all amenities Incl&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>33cb4fa1-ed88-4392-a080-d0cccf48e196</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Students Life in Naas College


 
 
 
 
	1) Professional Playground with all amenities Including Basketball, Volleyball Court.etc with Physical Trainer.
	



 
 
 
 
	2)College Bus Connectivity available to all parts in and around the city.
	



 
 
 
 
	3)Best education with Industry oriented approach!
	



 
 
 
 
	4)Effective Smart Classrooms and Digital Language Labs.
	
	


 
 
 
 
	5)Best auditorium for all events and exhibitions within the college premises.
	



 
 
 
 
	6)Highly Configured Computer Labs and Classrooms with all Amenities.(250+ Systems)
	
</value>
      <webElementGuid>5fedeb30-457b-4464-be5d-c6a954989d90</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]</value>
      <webElementGuid>64a524c8-4c9b-4e33-9061-ceb4e3783d3e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div</value>
      <webElementGuid>8a97f7b9-650b-4d84-b801-a8dadc04dcb5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='STUDENTS LIFE'])[2]/following::div[4]</value>
      <webElementGuid>f7bde9b3-162b-474a-bd7b-98a98710772c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gallery'])[1]/following::div[13]</value>
      <webElementGuid>f3fbabb8-d79e-4f62-a233-edeeeca76ff7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About Us'])[2]/preceding::div[20]</value>
      <webElementGuid>b4d0fd2d-afbb-4a30-b141-4755d6e39505</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[2]/div/div/div/div</value>
      <webElementGuid>c077151e-78c4-4071-9e94-0fbe7fc16fed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Students Life in Naas College


 
 
 
 
	1) Professional Playground with all amenities Including Basketball, Volleyball Court.etc with Physical Trainer.
	



 
 
 
 
	2)College Bus Connectivity available to all parts in and around the city.
	



 
 
 
 
	3)Best education with Industry oriented approach!
	



 
 
 
 
	4)Effective Smart Classrooms and Digital Language Labs.
	
	


 
 
 
 
	5)Best auditorium for all events and exhibitions within the college premises.
	



 
 
 
 
	6)Highly Configured Computer Labs and Classrooms with all Amenities.(250+ Systems)
	
' or . = 'Students Life in Naas College


 
 
 
 
	1) Professional Playground with all amenities Including Basketball, Volleyball Court.etc with Physical Trainer.
	



 
 
 
 
	2)College Bus Connectivity available to all parts in and around the city.
	



 
 
 
 
	3)Best education with Industry oriented approach!
	



 
 
 
 
	4)Effective Smart Classrooms and Digital Language Labs.
	
	


 
 
 
 
	5)Best auditorium for all events and exhibitions within the college premises.
	



 
 
 
 
	6)Highly Configured Computer Labs and Classrooms with all Amenities.(250+ Systems)
	
')]</value>
      <webElementGuid>4f593f6d-b99b-4486-9f49-82ff914d8723</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
