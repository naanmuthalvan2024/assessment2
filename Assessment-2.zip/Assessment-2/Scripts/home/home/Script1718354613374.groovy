import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://naascollege.com/')

WebUI.click(findTestObject('Object Repository/home test/Page_NAGARATHINAM ANGALAMMAL ARTS AND SCIEN_5c9298/div_AnnouncementsAdmission 2024 - 2025  Cos_3437de'))

WebUI.click(findTestObject('Object Repository/home test/Page_NAGARATHINAM ANGALAMMAL ARTS AND SCIEN_5c9298/div_College bus to pickup and Drop the stud_5a06cb'))

WebUI.click(findTestObject('Object Repository/home test/Page_NAGARATHINAM ANGALAMMAL ARTS AND SCIEN_5c9298/div_VisionThe College is to empower the stu_e575b8'))

WebUI.click(findTestObject('Object Repository/home test/Page_NAGARATHINAM ANGALAMMAL ARTS AND SCIEN_5c9298/div_FeaturesMagnificent Infrastructure.Smar_dc9d7e'))

WebUI.click(findTestObject('Object Repository/home test/Page_NAGARATHINAM ANGALAMMAL ARTS AND SCIEN_5c9298/a_ReadMore'))

WebUI.click(findTestObject('Object Repository/home test/Page_ABOUT US/h1_ABOUT US'))

WebUI.click(findTestObject('Object Repository/home test/Page_ABOUT US/h2_ABOUT US'))

WebUI.click(findTestObject('Object Repository/home test/Page_ABOUT US/div_Nagarathinam Angalammal Arts  Science C_36a12a'))

WebUI.click(findTestObject('Object Repository/home test/Page_ABOUT US/h1_ABOUT US'))

WebUI.click(findTestObject('Object Repository/home test/Page_ABOUT US/img_MANAGEMENT_attachment-large size-large _fc14b9'))

WebUI.click(findTestObject('Object Repository/home test/Page_ABOUT US/h4_Dr.S.Nagarathinam'))

WebUI.click(findTestObject('Object Repository/home test/Page_ABOUT US/h4_Dr.N.Jegatheesan'))

WebUI.click(findTestObject('Object Repository/home test/Page_ABOUT US/div_Dr.N.Jegatheesan     Secretary  Correspondent'))

WebUI.click(findTestObject('Object Repository/home test/Page_ABOUT US/p_Education is a prerequisite to progress a_ce263f'))

WebUI.click(findTestObject('Object Repository/home test/Page_ABOUT US/p_Education is a prerequisite to progress a_ce263f'))

WebUI.click(findTestObject('Object Repository/home test/Page_ABOUT US/img_Lead to Illuminate_w-100'))

WebUI.click(findTestObject('Object Repository/home test/Page_ABOUT US/p_91 96559 15151 naascollegegmail.com'))

WebUI.click(findTestObject('Object Repository/home test/Page_ABOUT US/div_S.No.321,Valayankulam Village, Near Air_0f8fda'))

WebUI.click(findTestObject('Object Repository/home test/Page_ABOUT US/div_S.No.321,Valayankulam Village, Near Air_0f8fda'))

WebUI.click(findTestObject('Object Repository/home test/Page_ABOUT US/a_Home'))

WebUI.click(findTestObject('Object Repository/home test/Page_NAGARATHINAM ANGALAMMAL ARTS AND SCIEN_5c9298/p_2024 Admission Starts Click Here To Apply Now'))

WebUI.switchToWindowTitle('Online Admission for the Academic Year - 2024-2025')

WebUI.selectOptionByValue(findTestObject('Object Repository/home test/Page_Online Admission for the Academic Year_4e98ef/select_UG CoursesPG Courses'), 
    'pg', true)

WebUI.setText(findTestObject('Object Repository/home test/Page_Online Admission for the Academic Year_4e98ef/input__i__userName'), 
    '85852787859')

WebUI.click(findTestObject('Object Repository/home test/Page_Online Admission for the Academic Year_4e98ef/input__i__userName'))

WebUI.setText(findTestObject('Object Repository/home test/Page_Online Admission for the Academic Year_4e98ef/input_Candidate date of birth is required_i_815798'), 
    '93867')

WebUI.click(findTestObject('Object Repository/home test/Page_Online Admission for the Academic Year_4e98ef/button_Sign In'))

WebUI.click(findTestObject('Object Repository/home test/Page_Online Admission for the Academic Year_4e98ef/button_Candidate date of birth is required__611ef2'))

WebUI.click(findTestObject('Object Repository/home test/Page_Online Admission for the Academic Year_4e98ef/button_Candidate date of birth is required__611ef2'))

WebUI.click(findTestObject('Object Repository/home test/Page_Online Admission for the Academic Year_4e98ef/div_Captcha code is required'))

WebUI.setText(findTestObject('Object Repository/home test/Page_Online Admission for the Academic Year_4e98ef/input_Candidate date of birth is required_i_815798'), 
    '449783')

WebUI.click(findTestObject('Object Repository/home test/Page_Online Admission for the Academic Year_4e98ef/button_Sign In'))

WebUI.click(findTestObject('Object Repository/home test/Page_Online Admission for the Academic Year_4e98ef/a_Click here'))

WebUI.click(findTestObject('Object Repository/home test/Page_Online Admission for the Academic Year_4e98ef/li_Apply for UG'))

WebUI.click(findTestObject('Object Repository/home test/Page_Online Admission for the Academic Year_4e98ef/li_Apply for PG'))

WebUI.click(findTestObject('Object Repository/home test/Page_Online Admission for the Academic Year_4e98ef/li_Prospectus'))

WebUI.click(findTestObject('Object Repository/home test/Page_Online Admission for the Academic Year_4e98ef/a_NEW REGISTRATION'))

WebUI.click(findTestObject('Object Repository/home test/Page_Online Admission for the Academic Year_4e98ef/a_NEW REGISTRATION'))

WebUI.click(findTestObject('Object Repository/home test/Page_Online Admission for the Academic Year_4e98ef/img'))

WebUI.click(findTestObject('Object Repository/home test/Page_Online Admission for the Academic Year_4e98ef/a_College website'))

WebUI.switchToWindowTitle('College ERP')

WebUI.click(findTestObject('Object Repository/home test/Page_College ERP/i_Please login to your account_fa-regular fa-eye'))

WebUI.setText(findTestObject('Object Repository/home test/Page_College ERP/input_Please login to your account_username'), 
    'asdcSADfsadfsf')

WebUI.click(findTestObject('Object Repository/home test/Page_College ERP/input_Please login to your account_username'))

WebUI.setText(findTestObject('Object Repository/home test/Page_College ERP/input_Please login to your account_password'), 
    'sdfsdfASDFas')

WebUI.click(findTestObject('Object Repository/home test/Page_College ERP/body_You need to enable JavaScript to run t_bee8e7'))

WebUI.click(findTestObject('Object Repository/home test/Page_College ERP/body_You need to enable JavaScript to run t_bee8e7'))

WebUI.click(findTestObject('Object Repository/home test/Page_College ERP/button_LOG IN'))

WebUI.click(findTestObject('Object Repository/home test/Page_College ERP/a_Forgot Password'))

WebUI.setText(findTestObject('Object Repository/home test/Page_College ERP/input_Enter your registered mobile number, _152c3c'), 
    'ASDFsdaf')

WebUI.click(findTestObject('Object Repository/home test/Page_College ERP/div_Enter your Username_col-md-12'))

WebUI.setText(findTestObject('Object Repository/home test/Page_College ERP/input_Enter your Username_captcha'), '16478')

WebUI.click(findTestObject('Object Repository/home test/Page_College ERP/button_Next'))

