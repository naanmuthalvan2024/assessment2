import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://naascollege.com/')

WebUI.click(findTestObject('Object Repository/admission test/Page_NAGARATHINAM ANGALAMMAL ARTS AND SCIEN_5c9298/span_Admission'))

WebUI.click(findTestObject('Object Repository/admission test/Page_NAGARATHINAM ANGALAMMAL ARTS AND SCIEN_5c9298/div_Nagarathinam Angalammal Arts  Science C_2a8ad4'))

WebUI.click(findTestObject('Object Repository/admission test/Page_NAGARATHINAM ANGALAMMAL ARTS AND SCIEN_5c9298/section_WELCOME TO NAAS COLLEGENagarathinam_36455a'))

WebUI.click(findTestObject('Object Repository/admission test/Page_NAGARATHINAM ANGALAMMAL ARTS AND SCIEN_5c9298/span_Admission'))

WebUI.click(findTestObject('Object Repository/admission test/Page_NAGARATHINAM ANGALAMMAL ARTS AND SCIEN_5c9298/a_ONLINE APPLICATION'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ONLINE APPLICATION/h1_ONLINE APPLICATION'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ONLINE APPLICATION/h5_SCHOLARSHIP'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ONLINE APPLICATION/div_SCHOLARSHIP      Scholarship under the _8221f8'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ONLINE APPLICATION/span_Admission'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ONLINE APPLICATION/a_PROSPECT US'))

WebUI.click(findTestObject('Object Repository/admission test/Page_PROSPECT US/h1_PROSPECT US'))

WebUI.click(findTestObject('Object Repository/admission test/Page_PROSPECT US/div_PROSPECT US'))

WebUI.click(findTestObject('Object Repository/admission test/Page_PROSPECT US/span_Admission'))

WebUI.click(findTestObject('Object Repository/admission test/Page_PROSPECT US/a_ELIGIBILITY  CRITERIA'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ELIGIBILITY  CRITERIA/th_Pass in 2'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ELIGIBILITY  CRITERIA/th_BSc Chemistry'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ELIGIBILITY  CRITERIA/th_Pass in 2 with Chemistry, Mathematics an_86e76c'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ELIGIBILITY  CRITERIA/th_BSc Mathematics'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ELIGIBILITY  CRITERIA/th_Pass in 2 with Mathematics, Physics and _fa93de'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ELIGIBILITY  CRITERIA/th_BSc Computer Science'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ELIGIBILITY  CRITERIA/th_BSc Forensic Science'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ELIGIBILITY  CRITERIA/th_10th , 2 Science with Physics, Chemistry_52779e'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ELIGIBILITY  CRITERIA/th_B.Sc Cloud Computing  Cyber Security'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ELIGIBILITY  CRITERIA/th_B.Sc Electonics  Communication'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ELIGIBILITY  CRITERIA/th_Eligiblity is an Under Graduate Degree i_8c040b'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ELIGIBILITY  CRITERIA/th_Pass in 2'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ELIGIBILITY  CRITERIA/th_Eligiblity is an Under Graduate Degree i_8c040b'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ELIGIBILITY  CRITERIA/th_M.Sc Computer Science'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ELIGIBILITY  CRITERIA/th_COURSE NAME'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ELIGIBILITY  CRITERIA/a_ONLINE APPLICATION'))

WebUI.click(findTestObject('Object Repository/admission test/Page_ONLINE APPLICATION/span_Apply Now'))

WebUI.switchToWindowTitle('Online Admission for the Academic Year - 2024-2025')

WebUI.click(findTestObject('Object Repository/admission test/Page_Online Admission for the Academic Year_4e98ef/input__i__userName'))

WebUI.setText(findTestObject('Object Repository/admission test/Page_Online Admission for the Academic Year_4e98ef/input__i__userName'), 
    '858578445649')

WebUI.setText(findTestObject('Object Repository/admission test/Page_Online Admission for the Academic Year_4e98ef/input_Candidate date of birth is required_i_815798'), 
    '84226')

WebUI.click(findTestObject('Object Repository/admission test/Page_Online Admission for the Academic Year_4e98ef/button_Sign In'))

