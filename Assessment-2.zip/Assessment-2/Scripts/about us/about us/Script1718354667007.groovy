import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://naascollege.com/')

WebUI.click(findTestObject('Object Repository/about test/Page_NAGARATHINAM ANGALAMMAL ARTS AND SCIEN_5c9298/span_Previous_carousel-control-next-icon'))

WebUI.click(findTestObject('Object Repository/about test/Page_NAGARATHINAM ANGALAMMAL ARTS AND SCIEN_5c9298/span_Previous_carousel-control-next-icon'))

WebUI.click(findTestObject('Object Repository/about test/Page_NAGARATHINAM ANGALAMMAL ARTS AND SCIEN_5c9298/a_About Us'))

WebUI.click(findTestObject('Object Repository/about test/Page_ABOUT US/h1_ABOUT US'))

WebUI.click(findTestObject('Object Repository/about test/Page_ABOUT US/h2_ABOUT US'))

WebUI.click(findTestObject('Object Repository/about test/Page_ABOUT US/img_Nagarathinam Angalammal Arts  Science C_a553ca'))

WebUI.click(findTestObject('Object Repository/about test/Page_ABOUT US/h2_MANAGEMENT'))

WebUI.click(findTestObject('Object Repository/about test/Page_ABOUT US/h6_Secretary  Correspondent'))

WebUI.click(findTestObject('Object Repository/about test/Page_ABOUT US/img_Secretary  Correspondent_attachment-lar_1d963d'))

WebUI.click(findTestObject('Object Repository/about test/Page_ABOUT US/img_MANAGEMENT_attachment-large size-large _fc14b9'))

WebUI.click(findTestObject('Object Repository/about test/Page_ABOUT US/img_Chairman_attachment-large size-large wp_e75703'))

WebUI.click(findTestObject('Object Repository/about test/Page_ABOUT US/div_Chairman_elementor-spacer'))

WebUI.click(findTestObject('Object Repository/about test/Page_ABOUT US/div_ABOUT US     Nagarathinam Angalammal Ar_f77534'))

WebUI.click(findTestObject('Object Repository/about test/Page_ABOUT US/p_Education is a prerequisite to progress a_ce263f'))

WebUI.click(findTestObject('Object Repository/about test/Page_ABOUT US/p_NAAS College is a trend setter for youngs_ca0ecb'))

WebUI.click(findTestObject('Object Repository/about test/Page_ABOUT US/div_Education is a prerequisite to progress_321656'))

WebUI.click(findTestObject('Object Repository/about test/Page_ABOUT US/div_ABOUT US     Nagarathinam Angalammal Ar_f77534'))

WebUI.click(findTestObject('Object Repository/about test/Page_ABOUT US/p_S.No.321,Valayankulam Village, Near Airpo_690a7e'))

WebUI.click(findTestObject('Object Repository/about test/Page_ABOUT US/p_Nagarathinam Angalammal Arts  Science Col_23958f'))

WebUI.click(findTestObject('Object Repository/about test/Page_ABOUT US/p_Nagarathinam Angalammal Arts  Science Col_23958f'))

WebUI.click(findTestObject('Object Repository/about test/Page_ABOUT US/a_STUDENTS LIFE'))

WebUI.click(findTestObject('Object Repository/about test/Page_STUDENTS LIFE/h1_STUDENTS LIFE'))

WebUI.click(findTestObject('Object Repository/about test/Page_STUDENTS LIFE/h5_Students Life in Naas College'))

WebUI.click(findTestObject('Object Repository/about test/Page_STUDENTS LIFE/div_2)College Bus Connectivity available to_38efbf'))

WebUI.click(findTestObject('Object Repository/about test/Page_STUDENTS LIFE/div_Students Life in Naas College    1) Pro_072dd6'))

WebUI.click(findTestObject('Object Repository/about test/Page_STUDENTS LIFE/div_STUDENTS LIFE'))

WebUI.click(findTestObject('Object Repository/about test/Page_STUDENTS LIFE/h1_STUDENTS LIFE'))

WebUI.click(findTestObject('Object Repository/about test/Page_STUDENTS LIFE/h5_Students Life in Naas College'))

WebUI.click(findTestObject('Object Repository/about test/Page_STUDENTS LIFE/a_DEPARTMENTS'))

WebUI.click(findTestObject('Object Repository/about test/Page_Naas college/div_DEPARTMENT OF Commerce  Management'))

WebUI.click(findTestObject('Object Repository/about test/Page_Department of Commerce  Management/a_About Us'))

